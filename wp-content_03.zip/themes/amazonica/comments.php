<?php
/**
 * The template for displaying comments.
 *
 * Esta es la plantilla que muestra el área de la página que contiene tanto los comentarios actuales
 * como el formulario de comentario.
 */

// Evitar el acceso directo al archivo
if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME'])) {
    die('No se permite cargar esta página directamente.');
}

/*
 * Si la publicación actual está protegida por una contraseña y
 * el visitante aún no ha ingresado la contraseña, vamos a
 * regresar pronto sin cargar los comentarios.
 */
if (post_password_required()) {
    return '';
}

?>

<style>
    .comment-form-author label,
    .comment-form-email label,
    .comment-form-url label {
        display: block;
    }
</style>

<div id='comments'>
    <?php if (have_comments()) : ?>
        <h2 class='comments-title'>
            <?php
            $num_comments = get_comments_number(); // Obtener el número de comentarios
            if ($num_comments != 1) {
                printf(__('%s Comentarios', 'textdomain'), $num_comments);
            } else {
                _e('Un comentario', 'textdomain');
            }
            ?>
        </h2>

        <ol class='comment-list'>
            <?php
            wp_list_comments(array(
                'style'       => 'ol',
                'short_ping'  => true,
                'avatar_size' => 50,
            ));
            ?>
        </ol>

        <?php
        // ¿Hay comentarios por los cuales navegar?
        if (get_comment_pages_count() > 1 && get_option('page_comments')) : ?>
            <nav id="comment-nav-below" class="navigation comment-navigation" role="navigation">
                <div class="nav-previous"><?php previous_comments_link(__('&larr; Comentarios Antiguos', 'textdomain')); ?></div>
                <div class="nav-next"><?php next_comments_link(__('Comentarios Nuevos &rarr;', 'textdomain')); ?></div>
            </nav>
        <?php endif; ?>

    <?php endif; ?>

    <?php
    // Si los comentarios están cerrados y hay comentarios, dejemos una pequeña nota.
    if (!comments_open() && get_comments_number() && post_type_supports(get_post_type(), 'comments')) : ?>
        <p class='no-comments'><?php _e('Los comentarios están cerrados.', 'textdomain'); ?></p>
    <?php endif; ?>

    <?php
    $comments_args = array(
        'comment_field' => '<p class="comment-form-comment"><label for="comment">' . _x('Comment', 'noun') .
        '</label><br /><textarea id="comment" name="comment" cols="45" rows="8" aria-required="true" style="overflow: auto; width: 100%;"></textarea></p>',
    );
    comment_form($comments_args);
    ?>
</div><!-- #comments -->

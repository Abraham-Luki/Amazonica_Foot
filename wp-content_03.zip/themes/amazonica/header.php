<?php

/**
 * The template for displaying the header
 *
 * @package C:\laragon\www\genius\app/out/app-01
 */

// Obtener el ID de la página actual 
$page_id = get_queried_object_id();
// Obtener el título de la página usando el ID
$page_title = get_the_title($page_id);

?>
<!DOCTYPE html>
<html>

<head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8"><!-- /Added by HTTrack -->

	<meta charset="<?php bloginfo('charset'); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1">


	<?php
	$favicon_url = get_site_icon_url();
	if (empty($favicon_url)) {
		$favicon_url = esc_url(get_stylesheet_directory_uri() . '/assets/favicon.png');
	}
	echo '<link rel="icon" href="' . $favicon_url . '">';
	?>


	<!-- Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
	<link href="assets/fonts/MyFontsWebfontsKit.css" rel="stylesheet">

	<!-- Core Style -->

	<link href="assets/slick/slick.css" rel="stylehseet">




	<!-- Font Icons -->

	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js" id="jquery-js"></script>

	<!-- Custom CSS -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js" id="jquery-js"></script>


	<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">



	<style>
		img.wp-smiley,
		img.emoji {
			display: inline !important;
			border: none !important;
			box-shadow: none !important;
			height: 1em !important;
			width: 1em !important;
			margin: 0 0.07em !important;
			vertical-align: -0.1em !important;
			background: none !important;
			padding: 0 !important;
		}

		.block-hero-10 .mask-image {
			-webkit-mask: url('assets/images/blocks/preview/mask-blob.svg');
			mask: url('assets/images/blocks/preview/mask-blob.svg');
			-webkit-mask-position: center center;
			mask-position: center center;
			-webkit-mask-repeat: no-repeat;
			mask-repeat: no-repeat;
			-webkit-mask-size: 100% 100%;
		}

		.block-hero-10 .color {
			color: #385244 !important;
		}

		.block-hero-10 .bg-color {
			background-color: #385244 !important;
		}

		.block-hero-10 h1,
		.block-hero-10 h2,
		.block-hero-10 h3,
		.block-hero-10 h4,
		.block-hero-10 h5,
		.block-hero-10 h6 {
			font-family: Playfair Display, serif !important;
		}


		.block-hero-21 {
			--color: #326148;
			--color-secondary: 50, 97, 72;
			font-family: 'Roboto', sans-serif;
			background-image: radial-gradient(circle at top left, #53906f15 0%, #53906f15 15%, #fff 15%);
		}

		.block-hero-21 .font-primary {
			font-family: 'Lobster Two', cursive;
		}

		.block-hero-21 .color {
			color: #373d3a !important;
			text-transform: uppercase !important;
			font-weight: 600;
			font-size: 40px;
		}

		/* Rsponsivo  */
		/* Para pantallas pequeñas (móviles) */
		@media (max-width: 768px) {

			.block-hero-21 .color {
				color: #373d3a !important;
				text-transform: uppercase !important;
				font-weight: 600;
				font-size: 1rem;
			}

		}

		.block-hero-21 .bg-color {
			background-color: var(--color) !important;
		}

		.block-hero-21 .fbox-icon i {
			background-color: #EEE5CF;
			color: var(--color);
		}
	</style>



	<?php wp_head(); ?>
</head>

<body class="home page-template page-template-page-home page-template-page-home-php page page-id-10 siteorigin-panels siteorigin-panels-before-js siteorigin-panels-home">
	<!--Header-->

	<header>
		<div class="container">
			<div class="grid">
				<a class="logo" href="<?php echo home_url(); ?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/logo.png" alt="Amazonica"></a>

				<div class="slogan">
					<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/slogan.jpg" alt="Camposol Cares from Farm to Family">
				</div>

				<div class="right-header">
					<div class="flex-container">
						<div class="mini-menu">
							<a href="<?php echo esc_url(get_permalink(get_page_by_path('contacto'))); ?>">Contáctanos</a> |
							<a href="<?php echo esc_url(get_permalink(get_page_by_path('exportaciones'))); ?>">Exportaciones</a>
						 
							<!--|
								<a href="https://camposol.hiringroom.com/jobs" target="_blank">Work With Us</a>/-->
						</div>

						<div class="social-icons">
							<ul>
								<li><a href="<?php echo esc_url(get_option('facebook')); ?>" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/social/fb.png" alt="Facebook"></a></li>
								<li><a href="<?php echo esc_url(get_option('instagram')); ?>" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/social/instagram.png" alt="Instagram"></a></li>

								<li><a href="<?php echo esc_url(get_option('youtube')); ?>" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/social/youtube.png" alt="YouTube"></a></li>
							</ul>
						</div>

						<div class="menu-button-container">
							<button class="nav-button">
								<svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 39.67 35.6" class="svg open-button">
									<defs></defs>
									<g id="Layer_2" data-name="Layer 2">
										<g id="Layer_1-2" data-name="Layer 1">
											<rect class="cls-1" width="39.67" height="6.39">
											</rect>
											<rect class="cls-1" y="14.61" width="39.67" height="6.39">
											</rect>
											<rect class="cls-1" y="29.21" width="39.67" height="6.39">
											</rect>
										</g>
									</g>
								</svg>
								<!-- Generator: Adobe Illustrator 22.1.0, SVG Export Plug-In  -->
								<svg version="1.1" class="svg close-button" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" width="32.6px" height="32.6px" viewbox="0 0 32.6 32.6" style="enable-background:new 0 0 32.6 32.6;" xml:space="preserve">
									<defs></defs>
									<g id="Layer_2_2_">
										<g id="Layer_1-2_1_">
											<rect x="-3.6" y="13.1" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -6.7521 16.2875)" lass="st0" width="39.7" height="6.4">
											</rect>
											<rect x="13.1" y="-3.6" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -6.7425 16.2914)" class="st0" width="6.4" height="39.7"></rect>
										</g>
									</g>
								</svg>
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<div class="mobile-menu">
		<nav>
			<!-- --nav1 -->
			<?php
			if (get_option('is_active_menu')) {
				wp_nav_menu(array(
					'theme_location' => 'left-menu',
					'menu_class'     => 'menu',
					'menu_id'        => 'menu-item-96',
					'container'      => false,
					'depth'          => 2,
				));
			} else {
			?>
				<ul id="menu-primary" class="menu">
					<li id="menu-item-96" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-10 current_page_item menu-item-96"><a href="<?php echo home_url(); ?>" aria-current="page">Home</a></li>
					<li id="menu-item-3899" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-3899"><a href="<?php echo esc_url(get_permalink(get_page_by_path('nosotros'))); ?>">Nosotros</a>
						<ul class="sub-menu">
							<li id="menu-item-351" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-351"><a href="<?php echo esc_url(get_permalink(get_page_by_path('nuestra-historia'))); ?>">Nuestra historia</a></li>
							<li id="menu-item-350" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-350"><a href="<?php echo esc_url(get_permalink(get_page_by_path('mision-vision'))); ?>">Misión, visión, valores</a></li>

						</ul>
					</li>
					<li id="menu-item-102" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-102"><a href="#">Products</a>
						<ul class="sub-menu">
							<?php
							$args = array(
								'post_type' => 'fruta',
								'posts_per_page' => 10,
								'orderby' => 'date',
								'order' => 'DESC'
							);
							$query = new WP_Query($args);
							if ($query->have_posts()) :
								while ($query->have_posts()) : $query->the_post(); ?>
									<?php
									$image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
									if (!$image_url) {
										$image_url = 'https://via.placeholder.com/600x400';
									}
									$post_link = get_permalink();
									?>
									<li id="menu-item-103" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-103"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>

							<?php endwhile;
							endif;
							wp_reset_postdata();
							?>




						</ul>
					</li>

					<li id="menu-item-122" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-122"><a href="#">Comunidad</a>
						<ul class="sub-menu">

							<li id="menu-item-658" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-658"><a href="<?php echo esc_url(get_permalink(get_page_by_path('videos'))); ?>">Videos</a></li>
						 

						</ul>
					</li>
					<li id="menu-item-163" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-163"><a href="#">Contacto</a>
						<ul class="sub-menu">
							<li id="menu-item-136" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-136"><a href="<?php echo esc_url(get_permalink(get_page_by_path('contacto'))); ?>">Amazonica</a></li>
						</ul>
					</li>
				</ul>
		</nav><?php
			}
				?>

	</div>

	<nav id="main-nav">
		<!-- --nav2 -->
		<?php
		if (get_option('is_active_menu')) {
			wp_nav_menu(array(
				'theme_location' => 'right-menu',
				'menu_class'     => 'menu',
				'menu_id'        => 'menu-primary-1',
				'container'      => false,
				'depth'          => 2,
			));
		} else {
		?>
			<ul id="menu-primary-1" class="menu">
				<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-10 current_page_item menu-item-96"><a href="<?php echo home_url(); ?>" aria-current="page">Home</a></li>
				<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-3899"><a href="<?php echo esc_url(get_permalink(get_page_by_path('nosotros'))); ?>">Nosotros</a>
					<ul class="sub-menu">
						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-351"><a href="<?php echo esc_url(get_permalink(get_page_by_path('nuestra-historia'))); ?>">Nuestra historia</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-350"><a href="<?php echo esc_url(get_permalink(get_page_by_path('mision-vision'))); ?>">Visión, misión, valores</a></li>

						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-351"><a href="<?php echo esc_url(get_permalink(get_page_by_path('exportaciones'))); ?>">Exportaciones</a></li>

					</ul>
				</li>
				<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-102"><a href="#">Productos</a>
					<ul class="sub-menu">

						<?php
$args = array(
    'post_type' => 'fruta',
    'posts_per_page' => 5, // Limitar a los primeros 5 elementos
    'orderby' => 'date',
    'order' => 'DESC' // Cambiado a DESC para obtener los primeros 5
);
$query = new WP_Query($args);
if ($query->have_posts()) : 
    while ($query->have_posts()) : $query->the_post(); ?>
        <?php
        $image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
        if (!$image_url) {
            $image_url = 'https://via.placeholder.com/600x400';
        }
        $post_link = get_permalink();
        ?>
        <li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-103">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </li>
    <?php endwhile; 
endif;
wp_reset_postdata();
?>


					</ul>
				</li>

				<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-102"><a href="#">Productos</a>
					<ul class="sub-menu">

						<?php
$args = array(
    'post_type' => 'fruta',
    'posts_per_page' => 5, // Limitar a los primeros 5 elementos
    'orderby' => 'date',
    'order' => 'ASC' // Cambiado a DESC para obtener los primeros 5
);
$query = new WP_Query($args);
if ($query->have_posts()) : 
    while ($query->have_posts()) : $query->the_post(); ?>
        <?php
        $image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
        if (!$image_url) {
            $image_url = 'https://via.placeholder.com/600x400';
        }
        $post_link = get_permalink();
        ?>
        <li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-103">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </li>
    <?php endwhile; 
endif;
wp_reset_postdata();
?>

					</ul>
				</li>

				<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-122"><a href="#">Comunidad</a>
					<ul class="sub-menu">

						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-658"><a href="<?php echo esc_url(get_permalink(get_page_by_path('videos'))); ?>">Videos</a></li>
					 

					</ul>
				</li>
				<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-163"><a href="#">Contacto</a>
					<ul class="sub-menu">
						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-136"><a href="<?php echo esc_url(get_permalink(get_page_by_path('contacto'))); ?>">Amazonica</a></li>
					</ul>
				</li>
			</ul><?php
				}
					?>

	</nav>

	<!--Main Content-->
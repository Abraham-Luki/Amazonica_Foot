<?php
/**
 * Archivo Template: 404.php
 */
get_header();
?><div style="height: 100vh; display: flex; justify-content: center; align-items: center; flex-direction: column;">
                            <h2 style="font-size: 180px; font-weight: 900; text-align: center;">404</h2>
                            <h3>Upps... No encontramos la página. No existe aparentemente</h3>
                        </div>
<?php get_footer();

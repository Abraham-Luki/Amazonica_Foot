<?php
if ( is_front_page() && is_home() ) {
	// Default homepage (your blog posts index)
	get_template_part('home');
} elseif ( is_front_page() ) {
	// Static homepage
	$front_page_id = get_option('page_on_front');
	$front_page = get_post($front_page_id);
	$post_type = get_post_type($front_page);
	if ($front_page) {
		if ($post_type == 'page') {
			get_template_part('page', $front_page->post_name);
		} else {
			get_template_part('content', $post_type);
		}
	} else {
		echo "<p>No se ha encontrado la página estática configurada como inicio.</p>";
	}
} elseif ( is_home() ) {
	// Blog page
	get_template_part('index');
}

?>
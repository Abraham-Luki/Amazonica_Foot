<?php

/**
 * Template for Index
 */
get_header();
?>
<!-- Main content Start -->
<main id="main">

	<!--Hero-->

	<section id="hero">

		<section id="products-carousel">
		<?php
$args = array(
    'post_type' => 'fruta',
    'posts_per_page' => 10,
    'orderby' => 'date',
    'order' => 'DESC'
);
$query = new WP_Query($args);
if ($query->have_posts()) :
    while ($query->have_posts()) : $query->the_post(); 
        // Obtener la URL de imagen_1
        $image_url = get_post_meta(get_the_ID(), 'imagen_1', true);
        
        // Placeholder en caso de que imagen_1 no esté definida
        if (!$image_url) {
            $image_url = 'https://via.placeholder.com/600x400';
        }

        $post_link = get_permalink();
        ?>
        <div class="product product-50" style="background-image: url('<?php echo esc_url($image_url); ?>');">
            <a href="<?php echo esc_url($post_link); ?>" class="button">Descubre Más</a>
        </div>
    <?php 
    endwhile;
endif;
wp_reset_postdata();
?>



		</section>
	</section>

	<section id="tagline">
		<div class="container">
			<p>En Amazónica Foods EIRL, <span style="font-style: italic;" id="letter">exportamos</span> una amplia
				gama de productos agrícolas frescos y de alta calidad que representan lo
				mejor de la biodiversidad peruana. </p>
		</div>
	</section>
	<script>
		const words = ["sembramos", "cosechamos", "procesamos", "exportamos"];
		let currentIndex = 0;
		const spanElement = document.getElementById("letter");

		function changeText() {
			spanElement.style.opacity = 0; // Comienza a desvanecer el texto
			setTimeout(() => {
				spanElement.textContent = words[currentIndex]; // Cambia el texto
				spanElement.style.opacity = 1; // Vuelve a aparecer el texto
				currentIndex = (currentIndex + 1) % words.length; // Cicla a la siguiente palabra
			}, 100); // Espera 500ms para la transición
		}

		// Cambia el texto cada 2 segundos
		setInterval(changeText, 2000);
	</script>

	<section id="homepage-bottom">

		<div class="container">
			<div class="flex-container">
				<div class="home-bottom-left">
					<div class="featured-video">
						<?php
$args = array(
    'post_type' => 'videos',
    'meta_query' => array(
        array(
            'key' => 'is_active',
            'value' => '1',
            'compare' => '='
        )
    ),
    'posts_per_page' => 1 // Limita la consulta a un solo post
);

$active_video = new WP_Query($args);

if ($active_video->have_posts()) : 
    $active_video->the_post();
    
    // Obtener el enlace de YouTube, la URL de la imagen destacada, y el título
    $enlace_youtube = get_post_meta(get_the_ID(), 'enlace_youtube', true);
    $thumbnail_url = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'full') : 'assets/images/featured-video.jpg';
    $titulo = get_the_title();
?>
    <h2><?php echo esc_html($titulo); ?></h2>
    <a data-fancybox href="<?php echo esc_url($enlace_youtube); ?>">
        <img src="<?php echo esc_url($thumbnail_url); ?>" alt="Featured Video">
    </a>
<?php 
endif;
wp_reset_postdata();
?>

					</div>

					<div class="cares">
						<h2>Amazonica</h2>
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/social.png" alt="Social">
						<a href="<?php echo esc_url(get_post_type_archive_link('fruta')); ?>" class="button green">Conoce más sobre nosotros </a>
					</div>
				</div>

				<div class="home-bottom-right">
					<div class="latest-news">
						<h2>Exportamos felicidad</h2>
						<div class="news-post">
							<div class="image-container">

								<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/missing-picture-white.jpg" alt="Missing Picture White">
							</div>

							<a href="<?php echo esc_url(get_permalink(get_page_by_path('exportaciones'))); ?>" class="post-title">
								Amazónica Foods EIRL es una empresa peruana dedicada a la exportación
								de productos agrícolas de calidad premium a mercados de todo el
								mundo.</a>
							<div class="at-above-post-homepage addthis_tool" data-url="<?php echo esc_url(get_permalink(get_page_by_path('exportaciones'))); ?>"></div>
							<p> Nos especializamos en llevar lo mejor de la riqueza natural del
								Perú, desde productos frescos hasta procesados, con un enfoque en la
								sostenibilidad y el respeto por el medio ambiente.

								[…]<!-- AddThis Advanced Settings above via filter on get_the_excerpt --><!-- AddThis Advanced Settings below via filter on get_the_excerpt --><!-- AddThis Advanced Settings generic via filter on get_the_excerpt --><!-- AddThis Share Buttons above via filter on get_the_excerpt --><!-- AddThis Share Buttons below via filter on get_the_excerpt --></p>
							<div class="at-below-post-homepage addthis_tool" data-url="<?php echo esc_url(get_permalink(get_page_by_path('exportaciones'))); ?>"></div>
							<p><!-- AddThis Share Buttons generic via filter on get_the_excerpt --></p>

						</div>
						<div class="news-post">
							<div class="image-container">

								<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/missing-picture-white-2.jpg" alt="Missing Picture White 2">
							</div>

							<a href="<?php echo esc_url(get_permalink(get_page_by_path('exportaciones'))); ?>" class="post-title">
								Calidad Internacional desde la Mano de Productores Locales</a>
							<div class="at-above-post-homepage addthis_tool" data-url="<?php echo esc_url(get_permalink(get_page_by_path('exportaciones'))); ?>"></div>
							<p> Con un fuerte compromiso hacia la calidad, trabajamos estrechamente
								con productores locales para garantizar productos que cumplen con los
								más altos estándares internacionales, ofreciendo soluciones
								personalizadas para cada uno de nuestros clientes globales.
								[…]<!-- AddThis Advanced Settings above via filter on get_the_excerpt --><!-- AddThis Advanced Settings below via filter on get_the_excerpt --><!-- AddThis Advanced Settings generic via filter on get_the_excerpt --><!-- AddThis Share Buttons above via filter on get_the_excerpt --><!-- AddThis Share Buttons below via filter on get_the_excerpt --></p>
							<div class="at-below-post-homepage addthis_tool" data-url="<?php echo esc_url(get_permalink(get_page_by_path('exportaciones'))); ?>"></div>
							<p><!-- AddThis Share Buttons generic via filter on get_the_excerpt --></p>

						</div>
					</div>
				</div>
			</div>
		</div>

	</section>

	<section id="content" style="background-color: #eef8ec">
		<div class="content-wrap py-0">

			<div class="container  ">

				<!-- Section light
						============================================= -->

				<div class="block-hero-22 p-5 p-md-6  ">
					<div class="  border-top-0 m-0">
						<div style="position: relative;" class="container text-center">
							<img class="limon_move" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/limon-move.png" alt="Limon Move">

							<div class="heading-block text-center">

								<h2 class="rubberBand animated" data-animate="rubberBand">¿Qué nos
									diferencia?</h2>
								<span>Compromiso con la máxima calidad</span>
							</div>

							<img class="limon_move_2" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/limon-move-2.png" alt="Limon Move 2">

						</div>
					</div>

					<div class="row justify-content-between align-items-center mb-6">
						<div class="col-lg-6 mb-5 mb-lg-0">
							<img style="width: 600px;" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/hero-22/1.png"" alt=" Image" class="shadow-lg">
						</div>
						<div class="col-lg-6">
							<h2 class="font-primary color">Exportación sostenible.</h2>
							<p>En Amazónica Foods EIRL, nos destacamos por ofrecer productos
								agrícolas de alta calidad gracias a nuestra estrecha relación con
								productores locales, nuestro compromiso con la sostenibilidad y un
								servicio personalizado. </p>
							<a href="<?php echo esc_url(get_permalink(get_page_by_path('exportaciones'))); ?>" class="button green">Conoce más<i class="fa-solid fa-chevron-right ms-1" style="position: relative; top: 1px;"></i></a>

						</div>
					</div>
					<div class="row justify-content-between col-mb-30">
						<div class="col-sm-6 col-lg-3 pe-lg-4">
							<h3 class="text-transform-none ls-0 h6 fw-semibold">Calidad
								Superior</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Productos agrícolas de
								calidad. Rigurosos controles en cada etapa de producción y exportación
								garantizan frescura y el fiel cumplimiento de los estándares
								internacionales.</p>
						</div>

						<div class="col-sm-6 col-lg-3 pe-lg-4">
							<h3 class="text-transform-none ls-0 h6 fw-semibold">Relación Directa
								con Productores</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Colaboración estrecha con
								pequeños agricultores locales que garantiza un suministro constante de
								productos frescos y de alta calidad, fortaleciendo comunidades
								agrícolas mediante programas de capacitación y apoyo técnico.</p>
						</div>

						<div class="col-sm-6 col-lg-3 pe-lg-4">
							<h3 class="text-transform-none ls-0 h6 fw-semibold">Prácticas
								Sostenibles</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Compromiso con prácticas
								agrícolas sostenibles que minimizan el impacto ambiental y promueven
								la biodiversidad, diferenciándonos de aquellos enfoques que priorizan
								la producción a corto plazo sin considerar su huella ecológica.</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Innovación en
								Productos y Servicios</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Pioneros en el desarrollo de
								nuevos productos y soluciones logísticas, manteniéndose a la
								vanguardia de las tendencias del mercado y adaptándose a las
								necesidades de los clientes.

							</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Atención
								Personalizada al Cliente</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Enfoque en un servicio
								personalizado que asegura la atención eficiente y efectiva de
								necesidades específicas. Un equipo siempre disponible para brindar
								asesoría y soporte de calidad.

							</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Compromiso
								Social</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Impulso de iniciativas para
								mejorar la calidad de vida de los productores y sus familias, en pro
								del desarrollo sostenible de sus comunidades.

							</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Diversidad de
								Productos</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Amplia gama de productos
								agrícolas frescos y exóticos que destacan la biodiversidad peruana,
								permitiendo atender diversos mercados y satisfacer una variedad de
								preferencias de los consumidores.

							</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Eficiencia en la
								Cadena de Suministro</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Procesos optimizados en cada
								etapa de la cadena de suministro, asegurando tiempos de entrega
								precisos y la frescura de los productos desde su origen hasta el
								destino final.

							</p>
						</div>

					</div>
				</div>

			</div>

		</div>

	</section><!-- #content end -->

	<div style="padding-top: 100px; padding-bottom: 0; margin-bottom: -72!important; background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/chalkboard-bg.jpg'); background-position: center; background-size: cover; background-repeat: no-repeat; background-attachment: fixed;" class="block-hero-21 fadeInDown animated " data-animate="fadeInDown">

		<div class="container ">

			<div class="row flex-row-reverse justify-content-between align-items-center g-6">
				<div class="col-lg-6 mt-5 mt-lg-0">
					<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/hero-21/1.jpg" alt="Image" class="z-1 position-relative" style="margin-bottom: -60px;">
				</div>
				<div class="col-lg-6">

					<h5 style="color: white!important;" class="ls-1 fw-normal text-black op-05  color mb-3 text-uppercase">Ellos
						ya confían</h5>
					<h2 style="color: white!important" class="display-4 text-transform-none ls-0 font-primary color">Consolidando
						nuestra presencia en mercados internacionales clave.</h2>
					<p style="color: white;" class="mw-xs fw-normal mb-5 text-larger">Gracias
						a nuestra calidad y
						sostenibilidad, hemos creado relaciones sólidas con distintos países,
						ofreciendo productos excepcionales y responsables.</p>
				</div>

			</div>

			<div id="oc-portfolio" class="owl-carousel portfolio-carousel carousel-widget owl-loaded owl-drag mt-4" data-pagi="false" data-items-xs="1" data-items-sm="2" data-items-md="3" data-items-lg="4">
				<div class="owl-stage-outer">
					<div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all; width: 1912px;">

						<div class="owl-item active" style="width: 219px; margin-right: 20px;">
							<div class="portfolio-item">
								<div class="portfolio-image">
									<a href="<?php echo esc_url(get_permalink(get_page_by_path('portfolio-single'))); ?>">
										<img class="green_border" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/1.webp" alt="Open Imagination">
									</a>
									<div class="bg-overlay">
										<div class="bg-overlay-content dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;">
											<a href="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/1.webp" class="overlay-trigger-icon bg-light text-dark not-animated" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeInUpSmall" data-hover-speed="350" data-lightbox="image" style="animation-duration: 350ms;"><i class="uil uil-plus"></i></a>
										</div>
										<div class="bg-overlay-bg dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;"></div>
									</div>
								</div>
								<div class="portfolio-desc">
									<h3 style="color: white!important;"> Agroindustria </h3>
									<!-- <span ><a style="color: white!important;" href="#">Media</a>, <a style="color: white!important;" href="#">Icons</a></span> -->
								</div>
							</div>
						</div>

						<div class="owl-item active" style="width: 219px; margin-right: 20px;">
							<div class="portfolio-item">
								<div class="portfolio-image">
									<a href="<?php echo esc_url(get_permalink(get_page_by_path('portfolio-single'))); ?>">
										<img class="green_border" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/2.webp" alt="Open Imagination">
									</a>
									<div class="bg-overlay">
										<div class="bg-overlay-content dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;">
											<a href="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/2.webp" class="overlay-trigger-icon bg-light text-dark not-animated" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeInUpSmall" data-hover-speed="350" data-lightbox="image" style="animation-duration: 350ms;"><i class="uil uil-plus"></i></a>
										</div>
										<div class="bg-overlay-bg dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;"></div>
									</div>
								</div>
								<div class="portfolio-desc">
									<h3 style="color: white!important;">Comercio internacional </h3>
									<!-- <span><a  style="color: white!important;"href="#">Media</a>, <a style="color: white!important;" href="#">Icons</a></span> -->
								</div>
							</div>
						</div>

						<div class="owl-item active" style="width: 219px; margin-right: 20px;">
							<div class="portfolio-item">
								<div class="portfolio-image">
									<a href="<?php echo esc_url(get_permalink(get_page_by_path('portfolio-single'))); ?>">
										<img class="green_border" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/3.webp" alt="Open Imagination">
									</a>
									<div class="bg-overlay">
										<div class="bg-overlay-content dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;">
											<a href="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/3.webp" class="overlay-trigger-icon bg-light text-dark not-animated" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeInUpSmall" data-hover-speed="350" data-lightbox="image" style="animation-duration: 350ms;"><i class="uil uil-plus"></i></a>
										</div>
										<div class="bg-overlay-bg dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;"></div>
									</div>
								</div>
								<div class="portfolio-desc">
									<h3 style="color: white!important;"> Exportación de productos </h3>
									<!-- <span><a style="color: white!important;" href="#">Media</a>, <a style="color: white!important;" href="#">Icons</a></span> -->
								</div>
							</div>
						</div>

						<div class="owl-item active" style="width: 219px; margin-right: 20px;">
							<div class="portfolio-item">
								<div class="portfolio-image ">
									<a href="<?php echo esc_url(get_permalink(get_page_by_path('portfolio-single'))); ?>">
										<img class="green_border" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/4.webp" alt="Open Imagination">
									</a>
									<div class="bg-overlay">
										<div class="bg-overlay-content dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;">
											<a href="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/4.webp" class="overlay-trigger-icon bg-light text-dark not-animated" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeInUpSmall" data-hover-speed="350" data-lightbox="image" style="animation-duration: 350ms;"><i class="uil uil-plus"></i></a>
										</div>
										<div class="bg-overlay-bg dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;"></div>
									</div>
								</div>
								<div class="portfolio-desc">
									<h3 style="color: white!important;"> Mercados de alimentos frescos y procesados </h3>
									<!-- <span><a style="color: white!important;" href="#">Media</a>, <a style="color: white!important;" href="#">Icons</a></span> -->
								</div>
							</div>
						</div>

					</div>
				</div>


			</div>

			<div class="line border-width-2 mt-4"></div>
		</div>

		<div class="section bg-white my-0   py-0">
			<div class="container-fluid py-5 " style="background: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/section-4.jpg') no-repeat 25% 100% / cover; background-attachment: fixed;">
				<div class="row justify-content-end align-items-md-center min-vh-60 mw-md">
					<div class="col-md-7 col-lg-5">
						<p style="font-size: 1.5rem; color: #212529;" class="mb-2  ">Unimos
							productores locales y clientes globales </p>

						<h2 style="font-weight: 900;" class="display-4 text-transform-none ls-0 font-primary color">Únete a
							Nuestra Red Internacional</h2>
						<div class="subscribe-widget" data-loader="button">
							<div class="widget-subscribe-form-result"></div>

							<?php echo do_shortcode('[shortcode_form_empresas]'); ?>


						</div>
					</div>
				</div>
		</div>
	</div>

</main>
<!-- Main content End -->
<?php
get_footer();

<?php
/**
 * Template for Uva
 */
get_header();
?>
<!-- Main content Start -->


		
		<div class="mobile-menu">
			<nav>
				<ul id="menu-primary" class="menu"><li id="menu-item-96" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-10 current_page_item menu-item-96"><a href="<?php echo home_url(); ?>" aria-current="page">Home</a></li>
					<li id="menu-item-3899" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-3899"><a href="<?php echo esc_url(get_permalink(get_page_by_path('nosotros'))); ?>">Nosotros</a>
						<ul class="sub-menu">
							<li id="menu-item-351" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-351"><a href="<?php echo esc_url(get_permalink(get_page_by_path('nuestra-historia'))); ?>">Nuestra historia</a></li>
							<li id="menu-item-350" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-350"><a href="<?php echo esc_url(get_permalink(get_page_by_path('mision-vision'))); ?>">Misión, visión, valores</a></li>

						</ul>
					</li>
					<li id="menu-item-102" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-102"><a href="#">Products</a>
						<ul class="sub-menu">
							<li id="menu-item-103" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-103"><a href="<?php echo esc_url(get_permalink(get_page_by_path('limon'))); ?>">Limón</a></li>
							<li id="menu-item-104" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-104"><a href="<?php echo esc_url(get_permalink(get_page_by_path('mango'))); ?>">Mango</a></li>
							<li id="menu-item-107" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-107"><a href="<?php echo esc_url(get_permalink(get_page_by_path('palta'))); ?>">Palta</a></li>
							<li id="menu-item-106" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-106"><a href="<?php echo esc_url(get_permalink(get_page_by_path('uva'))); ?>">Uva</a></li>
							<li id="menu-item-105" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-105"><a href="<?php echo esc_url(get_permalink(get_page_by_path('arandanos'))); ?>">Arándanos</a></li>

							<li id="menu-item-105" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-105"><a href="<?php echo esc_url(get_permalink(get_page_by_path('kion'))); ?>">Kion</a></li>
							<li id="menu-item-105" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-105"><a href="<?php echo esc_url(get_permalink(get_page_by_path('banano'))); ?>">Banano</a></li>

							<li id="menu-item-105" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-105"><a href="<?php echo esc_url(get_permalink(get_page_by_path('cerezas'))); ?>">Cereza</a></li>
							<li id="menu-item-105" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-105"><a href="<?php echo esc_url(get_permalink(get_page_by_path('cafe'))); ?>">Cafe</a></li>

							<li id="menu-item-105" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-105"><a href="<?php echo esc_url(get_permalink(get_page_by_path('cacao'))); ?>">Cacao</a></li>
						</ul>
					</li>

					<li id="menu-item-122" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-122"><a href="#">Comunidad</a>
						<ul class="sub-menu">

							<li id="menu-item-658" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-658"><a href="<?php echo esc_url(get_permalink(get_page_by_path('videos'))); ?>">Videos</a></li>
							<li id="menu-item-755" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-755"><a href="<?php echo esc_url(get_permalink(get_page_by_path('blog'))); ?>">Blog</a></li>

						</ul>
					</li>
					<li id="menu-item-163" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-163"><a href="#">Contacto</a>
						<ul class="sub-menu">
							<li id="menu-item-136" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-136"><a href="<?php echo esc_url(get_permalink(get_page_by_path('contacto'))); ?>">Amazonica</a></li>
						</ul>
					</li>
				</ul> </nav>
		</div>

		<nav id="main-nav">
			<ul id="menu-primary-1" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-10 current_page_item menu-item-96"><a href="<?php echo home_url(); ?>" aria-current="page">Home</a></li>
				<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-3899"><a href="<?php echo esc_url(get_permalink(get_page_by_path('nosotros'))); ?>">Nosotros</a>
					<ul class="sub-menu">
						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-351"><a href="<?php echo esc_url(get_permalink(get_page_by_path('nuestra-historia'))); ?>">Nuestra historia</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-350"><a href="<?php echo esc_url(get_permalink(get_page_by_path('mision-vision'))); ?>">Visión, misión, valores</a></li>

						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-351"><a href="<?php echo esc_url(get_permalink(get_page_by_path('exportaciones'))); ?>">Exportaciones</a></li>

					</ul>
				</li>
				<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-102"><a href="#">Productos</a>
					<ul class="sub-menu">
						<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-103"><a href="<?php echo esc_url(get_permalink(get_page_by_path('limon'))); ?>">Limón</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-104"><a href="<?php echo esc_url(get_permalink(get_page_by_path('mango'))); ?>">Mango</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-107"><a href="<?php echo esc_url(get_permalink(get_page_by_path('palta'))); ?>">Palta</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-106"><a href="<?php echo esc_url(get_permalink(get_page_by_path('uva'))); ?>">Uva</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-105"><a href="<?php echo esc_url(get_permalink(get_page_by_path('arandanos'))); ?>">Arándanos</a></li>
						 

					</ul>
				</li>

				<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-102"><a href="#">Productos</a>
					<ul class="sub-menu">

						<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-105"><a href="<?php echo esc_url(get_permalink(get_page_by_path('kion'))); ?>">Kion</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-105"><a href="<?php echo esc_url(get_permalink(get_page_by_path('banano'))); ?>">Banano</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-105"><a href="<?php echo esc_url(get_permalink(get_page_by_path('cerezas'))); ?>">Cerezas</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-105"><a href="<?php echo esc_url(get_permalink(get_page_by_path('cafe'))); ?>">Café peruano</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-105"><a href="<?php echo esc_url(get_permalink(get_page_by_path('cacao'))); ?>">Cacao peruano</a></li>

					</ul>
				</li>

				<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-122"><a href="#">Comunidad</a>
					<ul class="sub-menu">

						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-658"><a href="<?php echo esc_url(get_permalink(get_page_by_path('videos'))); ?>">Videos</a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-755"><a href="<?php echo esc_url(get_permalink(get_page_by_path('blog'))); ?>">Blog</a></li>

					</ul>
				</li>
				<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-163"><a href="#">Contacto</a>
					<ul class="sub-menu">
						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-136"><a href="<?php echo esc_url(get_permalink(get_page_by_path('contacto'))); ?>">Amazonica</a></li>
					</ul>
				</li>
			</ul>
		</nav>

		<!--Main Content-->

		<main id="main">

			<section id="hero" class="page-hero" style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/frutas/hero/5.webp'); background-position: center;">
			</section>

			<article class="page-content product-content">
				<div class="flex-container">
					<div class="product-right featured-recipe">
						<h2 style="color: white;">Características principales</h2>

						<img width="300" height="300" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/recipe4.jpg" alt="Recipe4"  class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt decoding="async" sizes="(max-width: 300px) 100vw, 300px">
						<!-- <p class="recipe-title"><strong>Avocado, Rice, Egg and Olive Oil
								Porridge</strong></p> -->

					 
					</div>

					<div class="product-left">
						<div class="flex-container">
							<div class="product-description">
								<h1>Uva:</h1>
								<img width="317" height="229" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/uva.jpg" alt="Uva"  class="product-image wp-post-image" alt decoding="async" fetchpriority="high" sizes="(max-width: 317px) 100vw, 317px"> <div class="at-above-post addthis_tool" data-url="/"></div><p>Reconocida por su dulzura y variedad, nuestras uvas frescas llegan a los mercados internacionales en perfectas condiciones.

									</p>
									<h2>Presencia Internacional</h2>
									<table>
										<tbody>
											<tr>
												<td><strong>Estados Unidos:</strong><br>
													Amplia aceptación y consumo de uvas frescas.
												</td>
											</tr>
											<tr>
												<td><strong>Canadá:</strong><br>
													Demanda creciente de frutas frescas.
												</td>
											</tr>
											<tr>
												<td><strong>Asia:</strong><br>
													Países como China y Japón, donde las uvas son altamente valoradas.
												</td>
											</tr>
										</tbody>
										
									</table>
									
									<!-- <p><strong>Congelado IQF</strong><br />
										Congelado IQF</p> -->
									
								<!-- AddThis Advanced Settings above via filter on the_content --><!-- AddThis Advanced Settings below via filter on the_content --><!-- AddThis Advanced Settings generic via filter on the_content --><!-- AddThis Share Buttons above via filter on the_content --><!-- AddThis Share Buttons below via filter on the_content --><div class="at-below-post addthis_tool" data-url="/"></div><!-- AddThis Share Buttons generic via filter on the_content -->
							</div>

							<div class="nutrition-facts">
								<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/uva-nutrition-facts.jpg" alt="Uva Nutrition Facts" >
							</div>
						</div>
					</div>

				</div>

				<section id="slider" class="slider-element dark block-hero-6" style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/chalkboard-bg.jpg');">
					<div class="bg-overlay z-1 d-md-block d-none" style="background: linear-gradient(to right, #FFF 0%, #FFF 35%, transparent 35%, transparent 100%)"></div>

					<div class="container z-2">
						<div class="row min-vh-100 align-items-center justify-content-sm-around py-5">
							<div class="col-md-6 order-md-last text-center">
								<!-- <i class="fa-solid fa-burger icon-5x"></i>								  -->
								<div class="col-12">
									<div class="row justify-content-between col-mb-50">
										<div class="col-md-12">
											<h3>Cultivos de la uva</h3>
											<div class="toggle toggle-bg">
												<div class="mb-4">
													<div class="toggle-title">
														En Amazonica Foods EIRL, nos especializamos en la producción de uva de alta calidad en Perú, una región privilegiada por su clima ideal para el cultivo de este fruto. Nos enfocamos en procesos sostenibles que aseguran uvas frescas y deliciosas, cumpliendo con altos estándares de calidad para el mercado internacional.
													</div>
												</div>
												<div>
													<p style="color: #FFF; text-align: justify;">
														<strong>Selección del Terreno y Preparación del Viñedo:</strong> Empezamos con la preparación del suelo para garantizar que las plantas de uva cuenten con un entorno rico en nutrientes. Utilizamos abonos orgánicos y métodos naturales para preparar el terreno, brindando a las vides una base sólida para su crecimiento.
													</p>
											
													<p style="color: #FFF; text-align: justify;">
														<strong>Cultivo y Riego de Precisión:</strong> Implementamos técnicas de riego tecnificado, como el riego por goteo, que optimiza el uso del agua y garantiza la hidratación constante de las plantas, especialmente en un clima semiárido. A lo largo del ciclo de crecimiento, llevamos un control cuidadoso del desarrollo de las vides, protegiéndolas de plagas y enfermedades con prácticas sostenibles.
													</p>
													
													<p style="color: #FFF; text-align: justify;">
														<strong>Cosecha en el Punto de Maduración Óptimo:</strong> La cosecha de nuestras uvas se realiza manualmente para preservar su frescura y calidad. Nuestro equipo de expertos selecciona cada racimo en su punto de maduración ideal, asegurando que cada uva tenga el sabor, color y textura característicos de nuestras uvas peruanas.
													</p>
													
													<p style="color: #FFF; text-align: justify;">
														<strong>Post-Cosecha y Empaque:</strong> Una vez cosechadas, las uvas son sometidas a un proceso de selección y limpieza en nuestras instalaciones. Con tecnología avanzada de empaque, cada racimo es clasificado, etiquetado y embalada cuidadosamente para su exportación, asegurando que llegue en óptimas condiciones al mercado internacional.
													</p>
											
													<p style="color: #FFF; text-align: justify;">
														Con un fuerte compromiso hacia la sostenibilidad y la calidad, Amazonica Foods EIRL se enorgullece de llevar a los consumidores uvas frescas, deliciosas y cultivadas con respeto por el medio ambiente.
													</p>
												</div>
											</div>
											

										</div>

									</div>
								</div>

							</div>

							<div class="col-md-4 mt-5 mt-md-0">

								<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/hero-4.jpg" alt="image" class="hero-img">
							</div>
						</div>
					</div>

				</section>

			</article>

			
			
			<section id="content" style="background-color: #eef8ec">
				<div class="content-wrap py-0">

					<div class="container  ">

						<!-- Section light
						============================================= -->

						<div class="block-hero-22 p-5 p-md-6  ">
							<div class="  border-top-0 m-0">
								<div style="position: relative;" class="container text-center">
									<img class="limon_move" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/limon-move.png" alt="">

									<div class="heading-block text-center">
										
										<h2 class="rubberBand animated" data-animate="rubberBand">¿Qué nos diferencia?</h2>
										<span>Compromiso con la máxima calidad</span>
									</div>

									<img class="limon_move_2" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/limon-move-2.png" alt="">

								</div>
							</div>

							<div class="row justify-content-between align-items-center mb-6">
								<div class="col-lg-6 mb-5 mb-lg-0">
									<img style="width: 600px;" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/hero-22/1.png" alt="Image" class="shadow-lg">
								</div>
								<div class="col-lg-6">
									<h2 class="font-primary color">Exportación sostenible.</h2>
									<p>En Amazónica Foods EIRL, nos destacamos por ofrecer productos
										agrícolas de alta calidad gracias a nuestra estrecha relación con
										productores locales, nuestro compromiso con la sostenibilidad y un
										servicio personalizado. </p>
									<a href="./exportaciones.html" class="button green">Conoce  más<i class="fa-solid fa-chevron-right ms-1" style="position: relative; top: 1px;"></i></a>

								</div>
							</div>
							<div class="row justify-content-between col-mb-30">
								<div class="col-sm-6 col-lg-3 pe-lg-4">
									<h3 class="text-transform-none ls-0 h6 fw-semibold">Calidad
										Superior</h3>
									<p class="text-dark mt-3 op-07 fw-normal">Productos agrícolas de calidad. Rigurosos controles en cada etapa de producción y exportación garantizan frescura y el fiel cumplimiento de los estándares internacionales.</p>
								</div>

								<div class="col-sm-6 col-lg-3 pe-lg-4">
									<h3 class="text-transform-none ls-0 h6 fw-semibold">Relación Directa con Productores</h3>
									<p class="text-dark mt-3 op-07 fw-normal">Colaboración estrecha con pequeños agricultores locales que garantiza un suministro constante de productos frescos y de alta calidad, fortaleciendo comunidades agrícolas mediante programas de capacitación y apoyo técnico.</p>
								</div>

								

								<div class="col-sm-6 col-lg-3 pe-lg-4">
									<h3 class="text-transform-none ls-0 h6 fw-semibold">Prácticas Sostenibles</h3>
									<p class="text-dark mt-3 op-07 fw-normal">Compromiso con prácticas agrícolas sostenibles que minimizan el impacto ambiental y promueven la biodiversidad, diferenciándonos de aquellos enfoques que priorizan la producción a corto plazo sin considerar su huella ecológica.</p>
								</div>

								<div class="col-sm-6 col-lg-3">
									<h3 class="text-transform-none ls-0 h6 fw-semibold"> Innovación en Productos y Servicios</h3>
									<p class="text-dark mt-3 op-07 fw-normal">Pioneros en el desarrollo de nuevos productos y soluciones logísticas, manteniéndose a la vanguardia de las tendencias del mercado y adaptándose a las necesidades de los clientes.

									</p>
								</div>

								<div class="col-sm-6 col-lg-3">
									<h3 class="text-transform-none ls-0 h6 fw-semibold"> Atención Personalizada al Cliente</h3>
									<p class="text-dark mt-3 op-07 fw-normal">Enfoque en un servicio personalizado que asegura la atención eficiente y efectiva de necesidades específicas. Un equipo siempre disponible para brindar asesoría y soporte de calidad.

									</p>
								</div>

								<div class="col-sm-6 col-lg-3">
									<h3 class="text-transform-none ls-0 h6 fw-semibold"> Compromiso Social</h3>
									<p class="text-dark mt-3 op-07 fw-normal">Impulso de iniciativas para mejorar la calidad de vida de los productores y sus familias, en pro del desarrollo sostenible de sus comunidades.

									</p>
								</div>

								<div class="col-sm-6 col-lg-3">
									<h3 class="text-transform-none ls-0 h6 fw-semibold"> Diversidad de Productos</h3>
									<p class="text-dark mt-3 op-07 fw-normal">Amplia gama de productos agrícolas frescos y exóticos que destacan la biodiversidad peruana, permitiendo atender diversos mercados y satisfacer una variedad de preferencias de los consumidores.

									</p>
								</div>

								<div class="col-sm-6 col-lg-3">
									<h3 class="text-transform-none ls-0 h6 fw-semibold"> Eficiencia en la Cadena de Suministro</h3>
									<p class="text-dark mt-3 op-07 fw-normal">Procesos optimizados en cada etapa de la cadena de suministro, asegurando tiempos de entrega precisos y la frescura de los productos desde su origen hasta el destino final.

									</p>
								</div>

								 
							</div>
						</div>

					</div>

				</div>

			</section><!-- #content end -->

			<div style="padding-top: 100px; padding-bottom: 30px; margin-bottom: -72!important; background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/chalkboard-bg.jpg'); background-position: center; background-size: cover; background-repeat: no-repeat; background-attachment: fixed;" class="block-hero-21 fadeInDown animated " data-animate="fadeInDown">

			<div class="container ">

			<div class="row flex-row-reverse justify-content-between align-items-center g-6">
				<div class="col-lg-6 mt-5 mt-lg-0">
					<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/hero-21/1.jpg" alt="Image" class="z-1 position-relative" style="margin-bottom: -60px;">
				</div>
				<div class="col-lg-6">

					<h5 style="color: white!important;" class="ls-1 fw-normal text-black op-05  color mb-3 text-uppercase">Ellos
						ya confían</h5>
					<h2 style="color: white!important" class="display-4 text-transform-none ls-0 font-primary color">Consolidando
						nuestra presencia en mercados internacionales clave.</h2>
					<p style="color: white;" class="mw-xs fw-normal mb-5 text-larger">Gracias
						a nuestra calidad y
						sostenibilidad, hemos creado relaciones sólidas con distintos países,
						ofreciendo productos excepcionales y responsables.</p>
				</div>

			</div>

			<div id="oc-portfolio" class="owl-carousel portfolio-carousel carousel-widget owl-loaded owl-drag mt-4" data-pagi="false" data-items-xs="1" data-items-sm="2" data-items-md="3" data-items-lg="4">
				<div class="owl-stage-outer">
					<div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all; width: 1912px;">

						<div class="owl-item active" style="width: 219px; margin-right: 20px;">
							<div class="portfolio-item">
								<div class="portfolio-image">
									<a href="<?php echo esc_url(get_permalink(get_page_by_path('portfolio-single'))); ?>">
										<img class="green_border" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/1.webp" alt="Open Imagination">
									</a>
									<div class="bg-overlay">
										<div class="bg-overlay-content dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;">
											<a href="assets/images/portfolio/4/1.webp" class="overlay-trigger-icon bg-light text-dark not-animated" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeInUpSmall" data-hover-speed="350" data-lightbox="image" style="animation-duration: 350ms;"><i class="uil uil-plus"></i></a>
										</div>
										<div class="bg-overlay-bg dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;"></div>
									</div>
								</div>
								<div class="portfolio-desc">
									<h3 style="color: white!important;"> Agroindustria </h3>
									<!-- <span ><a style="color: white!important;" href="#">Media</a>, <a style="color: white!important;" href="#">Icons</a></span> -->
								</div>
							</div>
						</div>

						<div class="owl-item active" style="width: 219px; margin-right: 20px;">
							<div class="portfolio-item">
								<div class="portfolio-image">
									<a href="<?php echo esc_url(get_permalink(get_page_by_path('portfolio-single'))); ?>">
										<img class="green_border" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/2.webp" alt="Open Imagination">
									</a>
									<div class="bg-overlay">
										<div class="bg-overlay-content dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;">
											<a href="assets/images/portfolio/4/2.webp" class="overlay-trigger-icon bg-light text-dark not-animated" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeInUpSmall" data-hover-speed="350" data-lightbox="image" style="animation-duration: 350ms;"><i class="uil uil-plus"></i></a>
										</div>
										<div class="bg-overlay-bg dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;"></div>
									</div>
								</div>
								<div class="portfolio-desc">
									<h3 style="color: white!important;">Comercio internacional </h3>
									<!-- <span><a  style="color: white!important;"href="#">Media</a>, <a style="color: white!important;" href="#">Icons</a></span> -->
								</div>
							</div>
						</div>

						<div class="owl-item active" style="width: 219px; margin-right: 20px;">
							<div class="portfolio-item">
								<div class="portfolio-image">
									<a href="<?php echo esc_url(get_permalink(get_page_by_path('portfolio-single'))); ?>">
										<img class="green_border" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/3.webp" alt="Open Imagination">
									</a>
									<div class="bg-overlay">
										<div class="bg-overlay-content dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;">
											<a href="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/3.webp" class="overlay-trigger-icon bg-light text-dark not-animated" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeInUpSmall" data-hover-speed="350" data-lightbox="image" style="animation-duration: 350ms;"><i class="uil uil-plus"></i></a>
										</div>
										<div class="bg-overlay-bg dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;"></div>
									</div>
								</div>
								<div class="portfolio-desc">
									<h3 style="color: white!important;"> Exportación de productos </h3>
									<!-- <span><a style="color: white!important;" href="#">Media</a>, <a style="color: white!important;" href="#">Icons</a></span> -->
								</div>
							</div>
						</div>

						<div class="owl-item active" style="width: 219px; margin-right: 20px;">
							<div class="portfolio-item">
								<div class="portfolio-image ">
									<a href="<?php echo esc_url(get_permalink(get_page_by_path('portfolio-single'))); ?>">
										<img class="green_border" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/4.webp" alt="Open Imagination">
									</a>
									<div class="bg-overlay">
										<div class="bg-overlay-content dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;">
											<a href="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/4.webp" class="overlay-trigger-icon bg-light text-dark not-animated" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeInUpSmall" data-hover-speed="350" data-lightbox="image" style="animation-duration: 350ms;"><i class="uil uil-plus"></i></a>
										</div>
										<div class="bg-overlay-bg dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;"></div>
									</div>
								</div>
								<div class="portfolio-desc">
									<h3 style="color: white!important;"> Mercados de alimentos frescos y procesados </h3>
									<!-- <span><a style="color: white!important;" href="#">Media</a>, <a style="color: white!important;" href="#">Icons</a></span> -->
								</div>
							</div>
						</div>

					</div>
				</div>


			</div>

			<div class="line border-width-2 mt-4"></div>
		</div>

				<div class="line border-width-2 mt-4"></div>
			</div>

			<div class="section bg-white my-0   py-0">
				<div class="container-fluid py-5 " style="background: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/section-4.jpg') no-repeat 25% 100% / cover; background-attachment: fixed;">
					<div class="row justify-content-end align-items-md-center min-vh-60 mw-md">
						<div class="col-md-7 col-lg-5">
							<p style="font-size: 1.5rem; color: #212529;" class="mb-2  ">Unimos
								productores locales y clientes globales </p>

							<h2 style="font-weight: 900;" class="display-4 text-transform-none ls-0 font-primary color">Únete a
								Nuestra Red Internacional</h2>
							<div class="subscribe-widget" data-loader="button">
								<div class="widget-subscribe-form-result"></div>
								
								<?php echo do_shortcode('[shortcode_form_empresas]'); ?>
								
							</div>
						</div>
					</div>
				</div>
			</div>

		</main>
		 

		<!--Footer-->

		<!-- Main content End -->
<?php
get_footer();


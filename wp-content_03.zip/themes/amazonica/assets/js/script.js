/************Document Ready Functions************/

jQuery(document).ready(function () {  
	
	jQuery('.mobile-menu nav').meanmenu({
		meanScreenWidth: "815"
	});
  
  jQuery('#products-carousel').slick({
	  infinite: true,
	  slidesToShow: 3,
	  slidesToScroll: 1,
	  autoplay: true,
	  prevArrow: '<button type="button" class="slick-prev"><img src="https://amazonicafoods.pe/wp-content/themes/amazonica/assets/images/prev-arrow.png" /></button>',
	  nextArrow: '<button type="button" class="slick-next"><img src="https://amazonicafoods.pe/wp-content/themes/amazonica/assets/images/next-arrow.png" /></button>',
	  responsive: [
	    {
	      breakpoint: 1024,
	      settings: {
	        slidesToShow: 3,
	        slidesToScroll: 1,
	      }
	    },
	    {
	      breakpoint: 930,
	      settings: {
	        slidesToShow: 2,
	        slidesToScroll: 1
	      }
	    },
	    {
	      breakpoint: 615,
	      settings: {
	        slidesToShow: 1,
	        slidesToScroll: 1
	      }
	    }
	    // You can unslick at a given breakpoint now by adding:
	    // settings: "unslick"
	    // instead of a settings object
	  ]
  });
  
  if (window.innerWidth > 815) {	
	  	    
	    jQuery('header .nav-button').click(function(e) {
		   e.preventDefault();
		   
			if ( jQuery('#main-nav').is(":visible") ) {
				jQuery('#main-nav').slideUp();
				
				jQuery('header').removeClass('expanded');
			} else {
				jQuery('#main-nav').slideDown(); 
				
				jQuery('header').addClass('expanded');
			}
	    });
	    
	    jQuery('#main-nav .close').click(function(e) {
		   e.preventDefault();
		   
		   jQuery('#main-nav').slideUp(); 
		   jQuery('header').removeClass('expanded');
	    });
    }
    
    if (window.innerWidth <= 782) {
	    $('.page-template-page-sidebar .page-content .left-column ul').each(function() {
		    var list = $(this), select = $(document.createElement('select')).insertBefore($(this).hide());
		
			// Create empty dropdown
			var emptyOption = $(document.createElement('option'))
				.appendTo(select)
				.val('#')
				.html('Navigation');
		
		    $('>li a', this).each(function() {
		        var target = $(this).attr('target'),
		        option = $(document.createElement('option'))
		            .appendTo(select)
		            .val(this.href)
		            .html($(this).html())
		    });
		    
		    list.remove();
		    
		    select.change(function() { window.location = $(this).find("option:selected").val(); });
		});
    }

});
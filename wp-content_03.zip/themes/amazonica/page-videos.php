<?php

/**
 * Template for Nuestra-historia
 */
get_header();
?>
<!-- Main content Start -->
<main id="main">
    <div class="page-template-page-sidebar">

        <!--Page Hero-->

        <section class="page-hero" style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/header-aboutus.jpg');">
        </section>
        <!--Page Content-->

        <article class="page-content">
            <div class="flex-container">
                <div class="left-column">
                    <h1>Menú</h1>
                    <ul>
                        <li><a href="<?php echo site_url('/nuestra-historia'); ?>">Nuestra historia</a></li>
                        <li><a href="<?php echo site_url('/videos'); ?>">Videos</a></li>
                        <li><a href="<?php echo site_url('/mision-vision'); ?>">Visión, misión...</a></li>
                    </ul>
                </div>

					<div class="right-column">
						<div class="at-above-post-page addthis_tool" data-url="/">
						</div>

						<div id="pl-647" class="panel-layout">
							<div id="pg-647-0" class="panel-grid panel-no-style">
								<div id="pgc-647-0-0" class="panel-grid-cell panel-grid-cell-empty">

								</div>
								 

							
							<div id="portfolio" class="portfolio row gutter-40">

								<!-- Portfolio Item: Start -->
								<?php
								$args = array(
									'post_type' => 'videos',
									'meta_query' => array(
										array(
											'key' => 'is_active',
											'value' => '1',
											'compare' => '='
										)
									)
								);
								$active_banners = new WP_Query($args);
								if ($active_banners->have_posts()) :
									while ($active_banners->have_posts()) : $active_banners->the_post();
										$enlace_youtube = get_post_meta(get_the_ID(), 'enlace_youtube', true);
										$duracion = get_post_meta(get_the_ID(), 'duracion', true);
								?>
										<!--- videos --->
										<article class="portfolio-item col-lg-4 col-md-4 col-sm-6 col-12">
											<!-- Grid Inner: Start -->
											<div class="grid-inner">
												<!-- Image: Start -->
												<div class="portfolio-image rounded-1">
													<a href="#">
														<img src="<?php if (has_post_thumbnail()) {
																		the_post_thumbnail_url("full");
																	} else {
																		echo "https://via.placeholder.com/600x400";
																	} ?>" alt="Open Imagination">
													</a>
													<!-- Overlay: Start -->
													<div class="bg-overlay">
														<div class="bg-overlay-content dark">
															<a href="<?php echo esc_html($enlace_youtube); ?>" class="overlay-trigger-icon text-size-xl text-white op-1" data-hover-animate="scaleIn" data-hover-animate-out="scaleOut" data-hover-speed="350" data-lightbox="iframe"><i class="bi-play-circle-fill"></i></a>
														</div>
														<div class="bg-overlay-bg bg-dark bg-opacity-40" data-hover-animate="fadeIn"></div>
													</div>
													<!-- Overlay: End -->
												</div>
												<!-- Image: End -->
												<!-- Decription: Start -->
												<div class="portfolio-desc">
													<h3><?php the_title(); ?></h3>
													<small class="text-contrast-500 font-monospace">
														Duraci&oacute;n
 <?php echo esc_html($duracion); ?>

													</small>
												</div>
												<!-- Description: End -->
											</div>
											<!-- Grid Inner: End -->
										</article><!--- endvideos --->
								<?php endwhile;
								endif;
								wp_reset_postdata();
								?>
								<!-- Portfolio Item: End -->

							</div><!-- #portfolio end -->


							</div>

						</div>


					</div>
				</div>
			</article>
		</main>
		<!-- Main content End -->
<?php
get_footer();


<?php
/*
Template Name: Frutas Single
Description: Mi Cpt de frutas
*/

get_header();
?>

<!-- Main content Start -->
<main id="main">

	<style>
		.page-hero {
			position: relative;
			overflow: hidden;
			width: 100%;
			height: 100vh;
			/* Ajusta la altura según sea necesario */
		}

		.hero-image {
			width: 100%;
			height: 100%;
			object-fit: cover;
			object-position: center;
			position: absolute;
			top: 0;
			left: 0;
			z-index: -1;
		}
	</style>



	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
			<!-- blog -->
			<section id="hero" class="page-hero">
				<img src="<?php if (has_post_thumbnail()) {
								echo get_the_post_thumbnail_url(get_the_ID(), "full");
							} else {
								echo "https://via.placeholder.com/600x400";
							} ?>" alt="Blueberry Hero Image" class="hero-image">
			</section>
			<article class="page-content product-content">
				<div class="flex-container">
					<div class="product-right featured-recipe">
						<h2 style="color: white;">Características principales</h2>

						<?php
								$image_url = get_post_meta(get_the_ID(), 'imagen_1', true);
								if (empty($image_url)) {
									$image_url = 'https://via.placeholder.com/600x400';
								}
								?>
								<img width="317" height="229" src="<?php echo esc_url($image_url); ?>" alt="Cereza" class="product-image wp-post-image" decoding="async" fetchpriority="high" sizes="(max-width: 317px) 100vw, 317px">
						<!-- <p class="recipe-title"><strong>Avocado, Rice, Egg and Olive Oil
							Porridge</strong></p> -->


					</div>

					<div class="product-left">
						<div class="flex-container">
							<div class="product-description">
								<h1><?php echo get_post_meta(get_the_ID(), 'titulo', true); ?></h1>
								<?php
								$image_url = get_post_meta(get_the_ID(), 'imagen_2', true);
								if (empty($image_url)) {
									$image_url = 'https://via.placeholder.com/600x400';
								}
								?>
								<img width="317" height="229" src="<?php echo esc_url($image_url); ?>" alt="Cereza" class="product-image wp-post-image" decoding="async" fetchpriority="high" sizes="(max-width: 317px) 100vw, 317px">


								<div class="at-above-post addthis_tool" data-url="/"></div>

								<p><?php echo get_post_meta(get_the_ID(), 'descripcion', true); ?></p>
								<h2>Presencia Internacional</h2>
								<p><?php the_content(); ?></p>

								<!-- <p><strong>Congelado IQF</strong><br />
									Congelado IQF</p> -->

								<!-- AddThis Advanced Settings above via filter on the_content --><!-- AddThis Advanced Settings below via filter on the_content --><!-- AddThis Advanced Settings generic via filter on the_content --><!-- AddThis Share Buttons above via filter on the_content --><!-- AddThis Share Buttons below via filter on the_content -->
								<div class="at-below-post addthis_tool" data-url="/"></div>
								<!-- AddThis Share Buttons generic via filter on the_content -->
							</div>

							<div class="nutrition-facts">
							<?php
								$image_url = get_post_meta(get_the_ID(), 'imagen_3', true);
								if (empty($image_url)) {
									$image_url = 'https://via.placeholder.com/600x400';
								}
								?>
								<img width="317" height="229" src="<?php echo esc_url($image_url); ?>" alt="Cereza" class="product-image wp-post-image" decoding="async" fetchpriority="high" sizes="(max-width: 317px) 100vw, 317px">
							</div>
						</div>
					</div>

				</div>



				<section data-cpt-except="true" id="slider" class="slider-element dark block-hero-6" style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/chalkboard-bg.jpg');">
					<div class="bg-overlay z-1 d-md-block d-none" style="background: linear-gradient(to right, #FFF 0%, #FFF 35%, transparent 35%, transparent 100%)"></div>

					<div class="container z-2">
						<div class="row min-vh-100 align-items-center justify-content-sm-around py-5">
							<div class="col-md-6 order-md-last text-center">
								<!-- <i class="fa-solid fa-burger icon-5x"></i>	-->
								<div class="col-12">
									<div class="row justify-content-between col-mb-50">
										<div class="col-md-12">
											<h3><?php echo get_post_meta(get_the_ID(), 'titulo_cultivo', true); ?></h3>
											<div class="toggle toggle-bg">
												<div class="mb-4">
													<div class="toggle-title">
														<?php echo get_post_meta(get_the_ID(), 'subitulo_cultivo', true); ?>
													</div>
												</div>
												<div>
													<p style="color: #FFF; text-align: justify;">
														<strong>Preparación del Terreno y Selección del Suelo:</strong> <?php echo get_post_meta(get_the_ID(), 'preparacion', true); ?>
													</p>

													<p style="color: #FFF; text-align: justify;">
														<strong>Cultivo y Manejo del Riego:</strong> <?php echo get_post_meta(get_the_ID(), 'cultivo', true); ?>
													</p>

													<p style="color: #FFF; text-align: justify;">
														<strong>Cosecha en el Punto Ideal de Maduración:</strong> <?php echo get_post_meta(get_the_ID(), 'consecha', true); ?>
													</p>

													<p style="color: #FFF; text-align: justify;">
														<strong>Post-Cosecha y Empaque:</strong> <?php echo get_post_meta(get_the_ID(), 'post_cosecha', true); ?>
													</p>

													<p style="color: #FFF; text-align: justify;"><?php echo get_post_meta(get_the_ID(), 'remate_cultivos', true); ?></p>
												</div>
											</div>


										</div>

									</div>
								</div>

							</div>

							<div class="col-md-4 mt-5 mt-md-0">

							<?php
								$image_url = get_post_meta(get_the_ID(), 'imagen_4', true);
								if (empty($image_url)) {
									$image_url = 'https://via.placeholder.com/600x400';
								}
								?>
								<img style="border: 6px solid #71b53e; margin: auto;" width="317" height="229" src="<?php echo esc_url($image_url); ?>"  class="product-image wp-post-image" decoding="async" fetchpriority="high" sizes="(max-width: 317px) 100vw, 317px">
							</div>
						</div>
					</div>

				</section>

			</article><!-- endblog -->
		<?php endwhile; ?>
		<div class="ghtml_pagination">
			<?php
			the_posts_pagination(array(
				"mid_size" => 2,
				"prev_text" => __("Anterior"),
				"next_text" => __("Siguiente"),
				"screen_reader_text" => __("Navegación de publicaciones"),
			));
			?>
		</div>
	<?php else : ?>
		<p style="text-align: center;">No hay publicaciones disponibles.</p>
	<?php endif; ?>




	<section id="content" style="background-color: #eef8ec">
		<div class="content-wrap py-0">

			<div class="container  ">

				<!-- Section light
					============================================= -->

				<div class="block-hero-22 p-5 p-md-6  ">
					<div class="  border-top-0 m-0">
						<div style="position: relative;" class="container text-center">
							<img class="limon_move" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/limon-move.png" alt="">

							<div class="heading-block text-center">

								<h2 class="rubberBand animated" data-animate="rubberBand">¿Qué nos diferencia?</h2>
								<span>Compromiso con la máxima calidad</span>
							</div>

							<img class="limon_move_2" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/limon-move-2.png" alt="">

						</div>
					</div>

					<div class="row justify-content-between align-items-center mb-6">
						<div class="col-lg-6 mb-5 mb-lg-0">
							<img style="width: 600px;" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/hero-22/1.png" alt="Image" class="shadow-lg">
						</div>
						<div class="col-lg-6">
							<h2 class="font-primary color">Exportación sostenible.</h2>
							<p>En Amazónica Foods EIRL, nos destacamos por ofrecer productos
								agrícolas de alta calidad gracias a nuestra estrecha relación con
								productores locales, nuestro compromiso con la sostenibilidad y un
								servicio personalizado. </p>
							<a href="<?php echo esc_url(get_permalink(get_page_by_path('exportaciones'))); ?>" class="button green">Conoce más<i class="fa-solid fa-chevron-right ms-1" style="position: relative; top: 1px;"></i></a>

						</div>
					</div>
					<div class="row justify-content-between col-mb-30">
						<div class="col-sm-6 col-lg-3 pe-lg-4">
							<h3 class="text-transform-none ls-0 h6 fw-semibold">Calidad
								Superior</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Productos agrícolas de calidad. Rigurosos controles en cada etapa de producción y exportación garantizan frescura y el fiel cumplimiento de los estándares internacionales.</p>
						</div>

						<div class="col-sm-6 col-lg-3 pe-lg-4">
							<h3 class="text-transform-none ls-0 h6 fw-semibold">Relación Directa con Productores</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Colaboración estrecha con pequeños agricultores locales que garantiza un suministro constante de productos frescos y de alta calidad, fortaleciendo comunidades agrícolas mediante programas de capacitación y apoyo técnico.</p>
						</div>



						<div class="col-sm-6 col-lg-3 pe-lg-4">
							<h3 class="text-transform-none ls-0 h6 fw-semibold">Prácticas Sostenibles</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Compromiso con prácticas agrícolas sostenibles que minimizan el impacto ambiental y promueven la biodiversidad, diferenciándonos de aquellos enfoques que priorizan la producción a corto plazo sin considerar su huella ecológica.</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Innovación en Productos y Servicios</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Pioneros en el desarrollo de nuevos productos y soluciones logísticas, manteniéndose a la vanguardia de las tendencias del mercado y adaptándose a las necesidades de los clientes.

							</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Atención Personalizada al Cliente</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Enfoque en un servicio personalizado que asegura la atención eficiente y efectiva de necesidades específicas. Un equipo siempre disponible para brindar asesoría y soporte de calidad.

							</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Compromiso Social</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Impulso de iniciativas para mejorar la calidad de vida de los productores y sus familias, en pro del desarrollo sostenible de sus comunidades.

							</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Diversidad de Productos</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Amplia gama de productos agrícolas frescos y exóticos que destacan la biodiversidad peruana, permitiendo atender diversos mercados y satisfacer una variedad de preferencias de los consumidores.

							</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Eficiencia en la Cadena de Suministro</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Procesos optimizados en cada etapa de la cadena de suministro, asegurando tiempos de entrega precisos y la frescura de los productos desde su origen hasta el destino final.

							</p>
						</div>


					</div>
				</div>

			</div>

		</div>

	</section><!-- #content end -->

	<div style="padding-top: 100px; padding-bottom: 30px; margin-bottom: -72!important; background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/chalkboard-bg.jpg'); background-position: center; background-size: cover; background-repeat: no-repeat; background-attachment: fixed;" class="block-hero-21 fadeInDown animated " data-animate="fadeInDown">

		<div class="container ">

			<div class="row flex-row-reverse justify-content-between align-items-center g-6">
				<div class="col-lg-6 mt-5 mt-lg-0">
					<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/hero-21/1.jpg" alt="Image" class="z-1 position-relative" style="margin-bottom: -60px;">
				</div>
				<div class="col-lg-6">

					<h5 style="color: white!important;" class="ls-1 fw-normal text-black op-05  color mb-3 text-uppercase">Ellos
						ya confían</h5>
					<h2 style="color: white!important" class="display-4 text-transform-none ls-0 font-primary color">Consolidando
						nuestra presencia en mercados internacionales clave.</h2>
					<p style="color: white;" class="mw-xs fw-normal mb-5 text-larger">Gracias
						a nuestra calidad y
						sostenibilidad, hemos creado relaciones sólidas con distintos países,
						ofreciendo productos excepcionales y responsables.</p>
				</div>

			</div>

			<div id="oc-portfolio" class="owl-carousel portfolio-carousel carousel-widget owl-loaded owl-drag mt-4" data-pagi="false" data-items-xs="1" data-items-sm="2" data-items-md="3" data-items-lg="4">
				<div class="owl-stage-outer">
					<div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all; width: 1912px;">

						<div class="owl-item active" style="width: 219px; margin-right: 20px;">
							<div class="portfolio-item">
								<div class="portfolio-image">
									<a href="<?php echo esc_url(get_permalink(get_page_by_path('portfolio-single'))); ?>">
										<img class="green_border" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/1.webp" alt="Open Imagination">
									</a>
									<div class="bg-overlay">
										<div class="bg-overlay-content dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;">
											<a href="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/1.webp" class="overlay-trigger-icon bg-light text-dark not-animated" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeInUpSmall" data-hover-speed="350" data-lightbox="image" style="animation-duration: 350ms;"><i class="uil uil-plus"></i></a>
										</div>
										<div class="bg-overlay-bg dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;"></div>
									</div>
								</div>
								<div class="portfolio-desc">
									<h3 style="color: white!important;"> Agroindustria </h3>
									<!-- <span ><a style="color: white!important;" href="#">Media</a>, <a style="color: white!important;" href="#">Icons</a></span> -->
								</div>
							</div>
						</div>

						<div class="owl-item active" style="width: 219px; margin-right: 20px;">
							<div class="portfolio-item">
								<div class="portfolio-image">
									<a href="<?php echo esc_url(get_permalink(get_page_by_path('portfolio-single'))); ?>">
										<img class="green_border" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/2.webp" alt="Open Imagination">
									</a>
									<div class="bg-overlay">
										<div class="bg-overlay-content dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;">
											<a href="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/2.webp" class="overlay-trigger-icon bg-light text-dark not-animated" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeInUpSmall" data-hover-speed="350" data-lightbox="image" style="animation-duration: 350ms;"><i class="uil uil-plus"></i></a>
										</div>
										<div class="bg-overlay-bg dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;"></div>
									</div>
								</div>
								<div class="portfolio-desc">
									<h3 style="color: white!important;">Comercio internacional </h3>
									<!-- <span><a  style="color: white!important;"href="#">Media</a>, <a style="color: white!important;" href="#">Icons</a></span> -->
								</div>
							</div>
						</div>

						<div class="owl-item active" style="width: 219px; margin-right: 20px;">
							<div class="portfolio-item">
								<div class="portfolio-image">
									<a href="<?php echo esc_url(get_permalink(get_page_by_path('portfolio-single'))); ?>">
										<img class="green_border" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/3.webp" alt="Open Imagination">
									</a>
									<div class="bg-overlay">
										<div class="bg-overlay-content dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;">
											<a href="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/3.webp" class="overlay-trigger-icon bg-light text-dark not-animated" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeInUpSmall" data-hover-speed="350" data-lightbox="image" style="animation-duration: 350ms;"><i class="uil uil-plus"></i></a>
										</div>
										<div class="bg-overlay-bg dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;"></div>
									</div>
								</div>
								<div class="portfolio-desc">
									<h3 style="color: white!important;"> Exportación de productos </h3>
									<!-- <span><a style="color: white!important;" href="#">Media</a>, <a style="color: white!important;" href="#">Icons</a></span> -->
								</div>
							</div>
						</div>

						<div class="owl-item active" style="width: 219px; margin-right: 20px;">
							<div class="portfolio-item">
								<div class="portfolio-image ">
									<a href="<?php echo esc_url(get_permalink(get_page_by_path('portfolio-single'))); ?>">
										<img class="green_border" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/4.webp" alt="Open Imagination">
									</a>
									<div class="bg-overlay">
										<div class="bg-overlay-content dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;">
											<a href="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/portfolio/4/4.webp" class="overlay-trigger-icon bg-light text-dark not-animated" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeInUpSmall" data-hover-speed="350" data-lightbox="image" style="animation-duration: 350ms;"><i class="uil uil-plus"></i></a>
										</div>
										<div class="bg-overlay-bg dark not-animated" data-hover-animate="fadeIn" data-hover-speed="350" data-bs-theme="dark" style="animation-duration: 350ms;"></div>
									</div>
								</div>
								<div class="portfolio-desc">
									<h3 style="color: white!important;"> Mercados de alimentos frescos y procesados </h3>
									<!-- <span><a style="color: white!important;" href="#">Media</a>, <a style="color: white!important;" href="#">Icons</a></span> -->
								</div>
							</div>
						</div>

					</div>
				</div>


			</div>

			<div class="line border-width-2 mt-4"></div>
		</div>

		<div class="line border-width-2 mt-4"></div>
	</div>

	<div class="section bg-white my-0   py-0">
		<div class="container-fluid py-5 " style="background: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/section-4.jpg') no-repeat 25% 100% / cover; background-attachment: fixed;">
			<div class="row justify-content-end align-items-md-center min-vh-60 mw-md">
				<div class="col-md-7 col-lg-5">
					<p style="font-size: 1.5rem; color: #212529;" class="mb-2  ">Unimos
						productores locales y clientes globales </p>

					<h2 style="font-weight: 900;" class="display-4 text-transform-none ls-0 font-primary color">Únete a
						Nuestra Red Internacional</h2>
					<div class="subscribe-widget" data-loader="button">
						<div class="widget-subscribe-form-result"></div>

						<?php echo do_shortcode('[shortcode_form_empresas]'); ?>

					</div>
				</div>
			</div>
		</div>
	</div>




</main>
<!-- Main content End -->

<?php
get_footer();
?>
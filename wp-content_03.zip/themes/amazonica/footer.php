<?php
/**
 * Footer template for the theme
 *
 */
?>
<footer>
			<div style="margin: 0;">

			</div>

			<div class="newsletter-signup">

				<div class="container">

					<div class="row justify-content-between  col-mb-50">
						<div class="col-md-5">

							<div class="widget">
								<p style="color: white;" class="text-larger mb-0"><span class="color">Suscríbete</span> a Nuestro Boletín para recibir
									Noticias Importantes, Ofertas Increíbles & Exclusivas:</p>
							</div>

						</div>

						<div class="col-md-5">

							<div class="widget subscribe-widget ligth">
								<div class="widget-subscribe-form-result"></div>
								
								<?php echo do_shortcode('[shortcode_form_suscripcion]'); ?>
								
							</div>
							<div class="mt-3 d-flex justify-content-md-end center_icons light">
								<div class="social-icons">
							<ul>
								<li><a href="<?php echo esc_url(get_option('facebook')); ?>" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/social/fb.png" alt="Facebook"></a></li>
								<li><a href="<?php echo esc_url(get_option('instagram')); ?>" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/social/instagram.png" alt="Instagram"></a></li>

								<li><a href="<?php echo esc_url(get_option('youtube')); ?>" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/social/youtube.png" alt="YouTube"></a></li>
							</ul>
						</div>
							</div>

						</div>

					</div>
				</div>
			</div>

			<div class="bottom-footer">
				<div class="container">
					<div class="footer-menu">
						<ul id="menu-primary-2" class="menu">

							<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-3899"><a href="./nosotros.html">Nosotros</a>
								<ul class="sub-menu">
									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-351"><a href="<?php echo esc_url(get_permalink(get_page_by_path('nuestra-historia'))); ?>">Nuestra historia</a></li>
									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-350"><a href="<?php echo esc_url(get_permalink(get_page_by_path('mision-vision'))); ?>">Misión, visión</a></li>

									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-350"><a href="<?php echo esc_url(get_permalink(get_page_by_path('exportaciones'))); ?>">Exportaciones</a></li>

								</ul>
							</li>
							<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-102"><a href="#">Productos</a>
								<ul class="sub-menu">
									<?php
$args = array(
    'post_type' => 'fruta',
    'posts_per_page' => 5,
    'orderby' => 'date',
    'order' => 'DESC'
);
$query = new WP_Query($args);
if ($query->have_posts()) : 
while ($query->have_posts()) : $query->the_post(); ?>
<?php
$image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
if (!$image_url) {
    $image_url = 'https://via.placeholder.com/600x400';
}
$post_link = get_permalink();
?>
<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-103"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>

<?php endwhile; 
endif;
wp_reset_postdata();
?>

								</ul>

							</li>

							<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-102"><a href="#">Productos</a>
							<ul class="sub-menu">
									<?php
$args = array(
    'post_type' => 'fruta',
    'posts_per_page' => 5, // Limitar a los últimos 5 elementos
    'orderby' => 'date',
    'order' => 'ASC' // Cambiado a ASC para obtener los últimos 5
);
$query = new WP_Query($args);
if ($query->have_posts()) : 
    while ($query->have_posts()) : $query->the_post(); ?>
        <?php
        $image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
        if (!$image_url) {
            $image_url = 'https://via.placeholder.com/600x400';
        }
        $post_link = get_permalink();
        ?>
        <li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-103">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </li>
    <?php endwhile; 
endif;
wp_reset_postdata();
?>

								</ul>

							</li>

							<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-122"><a href="#">Communidad</a>
								<ul class="sub-menu">
									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-658"><a href="<?php echo esc_url(get_permalink(get_page_by_path('videos'))); ?>">Videos</a></li>
									

								</ul>
							</li>
							<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-163"><a href="#">Contacto</a>
								<ul class="sub-menu">
									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-136"><a href="<?php echo esc_url(get_permalink(get_page_by_path('contacto'))); ?>">Amazonica</a></li>
								</ul>
							</li>
						</ul> </div>

					<div class="bottom">
						<div class="flex-container">
							<div class="lInfo">
								<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/logo.png" width="150" alt="grupo dc">
								<p class="copyright">© <?php echo esc_html(get_option('company')); ?>. All Rights Reserved. | <?php echo date('Y'); ?>
									 
								</p>
							</div>

							<div class="contact-info">

								<p><?php echo esc_html(get_option('address')); ?></p>
								<p>Teléfono: <a href="assets/tel:<?php echo esc_html(get_option('phone')); ?>"><?php echo esc_html(get_option('phone')); ?></a></p>
								<p>Email: <a href="assets/mailto:<?php echo esc_html(get_option('email')); ?>"><?php echo esc_html(get_option('email')); ?></a></p>


							</div>
<!-- companycomment -->

						</div>
					</div>
				</div>
			</div>
		</footer>

		<!--Scripts-->
		

<?php wp_footer(); ?>
</body>
</html>

<?php

/**
 * Template for Blog
 */
get_header();
?>
<!-- Main content Start -->
<main id="main">
	<div class="page-template-page-sidebar">

		<!--Page Hero-->

		<section class="page-hero" style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/header-news.jpg');">
		</section>
		<!--Page Content-->

		<article class="page-content">
			<div class="flex-container">
				<div class="left-column">
					<h1>Menú</h1>
					<ul>
						<li><a href="<?php echo site_url('/nuestra-historia'); ?>">Nuestra historia</a></li>
						<li><a href="<?php echo site_url('/videos'); ?>">Videos</a></li>
						<li><a href="<?php echo esc_url(get_permalink(get_page_by_path('blog'))); ?>">Blog</a></li>
						<li><a href="<?php echo site_url('/mision-vision'); ?>">Visión, misión...</a></li>
					</ul>
				</div>

				<div class="right-column">
					<h1>Blog</h1>

					<div class="news-container">

						<?php if (have_posts()) : ?>
							<?php while (have_posts()) : the_post(); ?>
								<!-- blog -->
								<div class="news-item">
									<div class="date">
										<span class="month"><?php the_time("M j, Y"); ?></span>

									</div>

									<div class="news-content">
										<h2><?php the_title(); ?></h2>
										<div class="content">
											<div class="image-preview">
											</div>

											<p class="post-excerpt"><?php the_excerpt(); ?></p>
										</div>
										<p class="source post-excerpt">

											<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
										</p>
									</div>
								</div><!-- endblog -->
							<?php endwhile; ?>
							<div class="ghtml_pagination">
								<?php
								the_posts_pagination(array(
									"mid_size" => 2,
									"prev_text" => __("Anterior"),
									"next_text" => __("Siguiente"),
									"screen_reader_text" => __("Navegación de publicaciones"),
								));
								?>
							</div>
						<?php else : ?>
							<p style="text-align: center;">No hay publicaciones disponibles.</p>
						<?php endif; ?>









						<div class="navigation">
							<span aria-current="page" class="page-numbers current">1</span>
							<a class="page-numbers" href="page/2/index.html">2</a>
							<a class="page-numbers" href="page/3/index.html">3</a>
							<span class="page-numbers dots">…</span>
							<a class="page-numbers" href="page/9/index.html">9</a>
							<a class="next page-numbers" href="page/2/index.html">Next »</a>
						</div>
					</div>
				</div>
			</div>
		</article>

	</div>

</main>
<!-- Main content End -->
<?php
get_footer();

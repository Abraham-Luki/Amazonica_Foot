<?php
// Llama al header del tema
get_header();

// Contenido del loop de WordPress para páginas
if ( have_posts() ) : 
    while ( have_posts() ) : the_post();
        // Muestra el título de la página
        echo '<div class="col-10 ">';
        echo '<h1>' . get_the_title() . '</h1>';
        // Muestra el contenido de la página
        echo "<div>".the_content()."</div>";
        echo '</div>';
    endwhile;
endif;

// Llama al footer del tema
get_footer();
?>
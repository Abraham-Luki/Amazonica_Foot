<?php
require_once(get_stylesheet_directory() . '/theme-config/config.php');
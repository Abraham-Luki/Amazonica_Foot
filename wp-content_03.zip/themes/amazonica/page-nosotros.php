<?php

/**
 * Template for Nosotros
 */
get_header();
?>
<!-- Main content Start -->
<main id="main">
    
    
    
<style>
    .page-hero {
        position: relative;
        overflow: hidden;
        width: 100%;
        height: 100vh;
        /* Ajusta la altura según sea necesario */
    }

    .hero-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: center;
        position: absolute;
        top: 0;
        left: 0;
        z-index: -1;
    }
    </style>

    <?php
    $user_selected_number = 1;
    $args = array(
        'post_type' => 'nosotros',
        'posts_per_page' => $user_selected_number,
        'orderby' => 'date',
        'order' => 'ASC',
        'meta_query' => array(
            array(
                'key' => 'is_active',
                'value' => '1',
                'compare' => '='
            )
        )
    );
    $latest_posts = new WP_Query($args);
    $counter = 1;
    if ($latest_posts->have_posts()) :
        while ($latest_posts->have_posts()) : $latest_posts->the_post();
            if ($counter == $user_selected_number) {
    ?>
    <!--- nosotros --->
    <div data-cpt-number="1" class="page-template-page-sidebar">
        <!--Page Hero-->

        <section id="hero" class="page-hero">
            <img src="<?php if (has_post_thumbnail()) {
                                        the_post_thumbnail_url("full");
                                    } else {
                                        echo "https://via.placeholder.com/600x400";
                                    } ?>" alt="Header News" class="hero-image">
        </section>
        <!--Page Content-->

        <article class="page-content">
            <div class="flex-container">
                <div data-cpt-except="true" class="left-column">
                <h1>Menú</h1>
                    <ul>
                            <li><a href="<?php echo site_url('/nuestra-historia'); ?>">Nuestra historia</a></li>
                            <li><a href="<?php echo site_url('/videos'); ?>">Videos</a></li>
                            <li><a href="<?php echo site_url('/mision-vision'); ?>">Visión, misión...</a></li>
                        </ul>
                </div>

                <div class="right-column">
                    <div class="at-above-post-page addthis_tool" data-url="/"></div>
                    <div id="pl-3873" class="panel-layout">
                        <div id="pg-3873-0" class="panel-grid panel-no-style">
                            <div id="pgc-3873-0-0" class="panel-grid-cell">
                                <div id="panel-3873-0-0-0"
                                    class="so-panel widget widget_sow-editor panel-first-child panel-last-child"
                                    data-index="0">
                                    <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                        <div class="siteorigin-widget-tinymce textwidget">
                                            <h1><?php the_title(); ?></h1>
                                            <p><?php the_content(); ?></p>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- AddThis Advanced Settings above via filter on the_content -->
                    <!-- AddThis Advanced Settings below via filter on the_content -->
                    <!-- AddThis Advanced Settings generic via filter on the_content -->
                    <!-- AddThis Share Buttons above via filter on the_content -->
                    <!-- AddThis Share Buttons below via filter on the_content -->
                    <div class="at-below-post-page addthis_tool" data-url="/"></div>
                    <!-- AddThis Share Buttons generic via filter on the_content -->
                </div>
            </div>
        </article>

    </div>
    <!--- endnosotros --->
    <?php
            }
            $counter++;
        endwhile;
    endif;
    wp_reset_postdata();
    ?>
    
    
    
    
    <div class="section bg-white my-0   py-0">
        <div class="container-fluid py-5 " style="background: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/section-4.jpg') no-repeat 25% 100% / cover; background-attachment: fixed;">
            <div class="row justify-content-end align-items-md-center min-vh-60 mw-md">
                <div class="col-md-7 col-lg-5">
                    <p style="font-size: 1.5rem; color: #212529;" class="mb-2  ">Unimos
                        productores locales y clientes globales </p>

                    <h2 style="font-weight: 900;" class="display-4 text-transform-none ls-0 font-primary color">Únete
                        a
                        Nuestra Red Internacional</h2>
                    <div class="subscribe-widget" data-loader="button">
                        <div class="widget-subscribe-form-result"></div>

                        <?php echo do_shortcode('[shortcode_form_empresas]'); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

</main>
<!-- Main content End -->
<?php
get_footer();

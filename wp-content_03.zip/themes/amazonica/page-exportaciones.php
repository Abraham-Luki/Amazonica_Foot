<?php

/**
 * Template for Exportaciones
 */
get_header();
?>
<!-- Main content Start -->
<main id="main">

	<style>
		.page-hero {
			position: relative;
			overflow: hidden;
			width: 100%;
			height: 100vh;
			/* Ajusta la altura según sea necesario */
		}

		.hero-image {
			width: 100%;
			height: 100%;
			object-fit: cover;
			object-position: center;
			position: absolute;
			top: 0;
			left: 0;
			z-index: -1;
		}
	</style>



	<!-- Section hero  -->

	<!--Hero-->


	<?php
	$args = array(
		'post_type' => 'exportaciones',
		'meta_query' => array(
			array(
				'key' => 'is_active',
				'value' => '1',
				'compare' => '='
			)
		)
	);
	$active_banners = new WP_Query($args);
	if ($active_banners->have_posts()) :
		while ($active_banners->have_posts()) : $active_banners->the_post();
	?>
			<!--- exportaciones --->
			<section id="hero" class="page-hero">
				<img src="<?php if (has_post_thumbnail()) {
								the_post_thumbnail_url("full");
							} else {
								echo  get_stylesheet_directory_uri() . "/assets/images/exportaciones/blueberry-hero.jpg";
							} ?>" alt="Blueberry Hero Image" class="hero-image">
			</section><!--- endexportaciones --->
	<?php endwhile;
	endif;
	wp_reset_postdata();
	?>


	<section id="tagline">
		<div class="container">
			<p>En Amazónica Foods EIRL, <span style="font-style: italic;" id="letter">exportamos</span> una amplia
				gama de productos agrícolas frescos y de alta calidad. Te repsentamos el proceso de exportación</p>
		</div>
	</section>





	<!--Carrusel-->
	<section id="products-carousel">
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/1.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/2.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/3.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/4.webp');">

		</div>

		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/5.webp');">

		</div>

		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/6.webp');">

		</div>

		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/7.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/8.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/9.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/10.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/11.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/12.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/13.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/14.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/15.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/16.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/17.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/18.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/19.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/20.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/21.webp');">

		</div>
		<div class="product " style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/exportaciones/22.webp');">

		</div>
	</section>

	<!--- endexportaciones --->



	<section id="content" style="background-color: #eef8ec">
		<div class="content-wrap py-0">

			<div class="container  ">

				<!-- Section light
						============================================= -->

				<div class="block-hero-22 p-5 p-md-6  ">
					<div class="  border-top-0 m-0">
						<div style="position: relative;" class="container text-center">
							<img class="limon_move" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/limon-move.png" alt="">

							<div class="heading-block text-center">

								<h2 class="rubberBand animated" data-animate="rubberBand">¿Qué nos diferencia?</h2>
								<span>Compromiso con la máxima calidad</span>
							</div>

							<img class="limon_move_2" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/limon-move-2.png" alt="">

						</div>
					</div>

					<div class="row justify-content-between align-items-center mb-6">
						<div class="col-lg-6 mb-5 mb-lg-0">
							<img style="width: 600px;" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/hero-22/1.png" alt="Image" class="shadow-lg">
						</div>
						<div class="col-lg-6">
							<h2 class="font-primary color">Exportación sostenible.</h2>
							<p>En Amazónica Foods EIRL, nos destacamos por ofrecer productos
								agrícolas de alta calidad gracias a nuestra estrecha relación con
								productores locales, nuestro compromiso con la sostenibilidad y un
								servicio personalizado. </p>
							<a href="<?php echo esc_url(get_permalink(get_page_by_path('contacto'))); ?>" class="button green">Contáctanos<i class="fa-solid fa-chevron-right ms-1" style="position: relative; top: 1px;"></i></a>

						</div>
					</div>
					<div class="row justify-content-between col-mb-30">
						<div class="col-sm-6 col-lg-3 pe-lg-4">
							<h3 class="text-transform-none ls-0 h6 fw-semibold">Calidad
								Superior</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Productos agrícolas de calidad. Rigurosos controles en cada etapa de producción y exportación garantizan frescura y el fiel cumplimiento de los estándares internacionales.</p>
						</div>

						<div class="col-sm-6 col-lg-3 pe-lg-4">
							<h3 class="text-transform-none ls-0 h6 fw-semibold">Relación Directa con Productores</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Colaboración estrecha con pequeños agricultores locales que garantiza un suministro constante de productos frescos y de alta calidad, fortaleciendo comunidades agrícolas mediante programas de capacitación y apoyo técnico.</p>
						</div>



						<div class="col-sm-6 col-lg-3 pe-lg-4">
							<h3 class="text-transform-none ls-0 h6 fw-semibold">Prácticas Sostenibles</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Compromiso con prácticas agrícolas sostenibles que minimizan el impacto ambiental y promueven la biodiversidad, diferenciándonos de aquellos enfoques que priorizan la producción a corto plazo sin considerar su huella ecológica.</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Innovación en Productos y Servicios</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Pioneros en el desarrollo de nuevos productos y soluciones logísticas, manteniéndose a la vanguardia de las tendencias del mercado y adaptándose a las necesidades de los clientes.

							</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Atención Personalizada al Cliente</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Enfoque en un servicio personalizado que asegura la atención eficiente y efectiva de necesidades específicas. Un equipo siempre disponible para brindar asesoría y soporte de calidad.

							</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Compromiso Social</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Impulso de iniciativas para mejorar la calidad de vida de los productores y sus familias, en pro del desarrollo sostenible de sus comunidades.

							</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Diversidad de Productos</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Amplia gama de productos agrícolas frescos y exóticos que destacan la biodiversidad peruana, permitiendo atender diversos mercados y satisfacer una variedad de preferencias de los consumidores.

							</p>
						</div>

						<div class="col-sm-6 col-lg-3">
							<h3 class="text-transform-none ls-0 h6 fw-semibold"> Eficiencia en la Cadena de Suministro</h3>
							<p class="text-dark mt-3 op-07 fw-normal">Procesos optimizados en cada etapa de la cadena de suministro, asegurando tiempos de entrega precisos y la frescura de los productos desde su origen hasta el destino final.

							</p>
						</div>


					</div>
				</div>

			</div>

		</div>

	</section><!-- #content end -->

	<div style="padding-top: 100px; padding-bottom: 30px; margin-bottom: -72!important; background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/chalkboard-bg.jpg'); background-position: center; background-size: cover; background-repeat: no-repeat; background-attachment: fixed;" class="block-hero-21  ">

		<div class="container-fluid">

			<div class="row mb-5 min-vh-100 align-items-center justify-content-between overflow-hidden   bg-opacity-10">
				<div class="col-lg-4 offset-lg-1 p-4">

					<div class="col-lg-6  mb-lg-0">
						<img class="img_exportaciones" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/hero-22/2.jpg" alt="Image">
					</div>
					<h3 class="display-4 fw-bold text-white">Exportaciones de Calidad Mundial</h3>
					<p class="text-white">Amazónica Foods EIRL lleva la riqueza agrícola del Perú a mercados internacionales, ofreciendo productos de calidad premium que cumplen con los más altos estándares de frescura y seguridad alimentaria. Con una logística optimizada y controles rigurosos en cada etapa, nuestras exportaciones aseguran que cada producto conserve su sabor y autenticidad, conectando a los consumidores globales con lo mejor de la biodiversidad peruana.</p>
				</div>

				<div class="col-lg-5 vh-100">
					<div class="grid-inner">
						<div class="row gx-3 scroll-detect gy-0">
							<div class="col-6">
								<div class="all-ts" style="--cnvs-transitions: .2s linear; transform: translate3d(0,calc(-25% + (1.5% * 100 * var(--cnvs-scroll-end, 0))),0);">
									<img class="mb-3" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/gallery-parallax/1.jpg" alt="..">
									<img class="mb-3" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/gallery-parallax/2.jpg" alt="..">
									<img class="mb-3" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/gallery-parallax/3.jpg" alt="..">
									<img class="mb-3" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/gallery-parallax/4.jpg" alt="..">
								</div>
							</div>
							<div class="col-6">
								<div class="all-ts" style="--cnvs-transitions: .2s linear; transform: translate3d(0,calc(-1% * 100 * var(--cnvs-scroll-end, 0)),0);">
									<img class="mb-3" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/gallery-parallax/6.jpg" alt="..">
									<img class="mb-3" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/gallery-parallax/5.jpg" alt="..">
									<img class="mb-3" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/gallery-parallax/3.jpg" alt="..">
									<img class="mb-3" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/blocks/preview/gallery-parallax/4.jpg" alt="..">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>


		</div>

		<div class="line border-width-2 mt-4"></div>
	</div>

	<div class="section bg-white my-0   py-0">
		<div class="container-fluid py-5 " style="background: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/section-4.jpg') no-repeat 25% 100% / cover; background-attachment: fixed;">
			<div class="row justify-content-end align-items-md-center min-vh-60 mw-md">
				<div class="col-md-7 col-lg-5">
					<p style="font-size: 1.5rem; color: #212529;" class="mb-2  ">Unimos
						productores locales y clientes globales </p>

					<h2 style="font-weight: 900;" class="display-4 text-transform-none ls-0 font-primary color">Únete a
						Nuestra Red Internacional</h2>
					<div class="subscribe-widget" data-loader="button">
						<div class="widget-subscribe-form-result"></div>

						<?php echo do_shortcode('[shortcode_form_empresas]'); ?>

					</div>
				</div>
			</div>
		</div>
	</div>

</main>
<!-- Main content End -->
<?php
get_footer();

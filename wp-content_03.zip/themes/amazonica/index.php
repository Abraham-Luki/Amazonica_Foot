<?php
// Llama al header del tema
get_header();

// Contenido del loop de WordPress
if ( have_posts() ) : 
    while ( have_posts() ) : the_post();
        // Muestra el contenido de las entradas
        the_content();
    endwhile;
endif;

// Llama al footer del tema
get_footer();
?>
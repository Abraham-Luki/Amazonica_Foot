<?php

/**
 * Template for Nuestra-historia
 */
get_header();
?>
<!-- Main content Start -->
<main id="main">
    <div class="page-template-page-sidebar">

        <!--Page Hero-->

        <section class="page-hero" style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/header-aboutus.jpg');">
        </section>
        <!--Page Content-->

        <article class="page-content">
            <div class="flex-container">
                <div class="left-column">
                    <h1>Menú</h1>
                    <ul>
                        <li><a href="<?php echo site_url('/nuestra-historia'); ?>">Nuestra historia</a></li>
                        <li><a href="<?php echo site_url('/videos'); ?>">Videos</a></li>
                        <li><a href="<?php echo esc_url(get_permalink(get_page_by_path('blog'))); ?>">Blog</a></li>
                        <li><a href="<?php echo site_url('/mision-vision'); ?>">Visión, misión...</a></li>
                    </ul>
                </div>

                <div class="right-column">
                    <div class="at-above-post-page addthis_tool" data-url="/"></div>
                    <div id="pl-250" class="panel-layout">
                        <div id="pg-250-0" class="panel-grid panel-no-style">
                            <div id="pgc-250-0-0" class="panel-grid-cell">
                                <div id="panel-250-0-0-0" class="so-panel widget widget_sow-editor panel-first-child panel-last-child" data-index="0">
                                    <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                        <div class="siteorigin-widget-tinymce textwidget">
                                            <h1>Nuestra historia</h1>
                                            <p>Amazónica Foods EIRL
                                                nació con la visión de
                                                conectar los tesoros
                                                agrícolas del Perú con
                                                el mundo. Desde nuestros
                                                inicios, nos propusimos
                                                trabajar de la mano con
                                                pequeños productores y
                                                agricultores locales,
                                                brindándoles no solo una
                                                plataforma para llevar
                                                sus productos a mercados
                                                internacionales, sino
                                                también acceso a
                                                tecnología y prácticas
                                                sostenibles que mejoran
                                                su calidad de vida y la
                                                de sus comunidades.</p>
                                            <p>Nuestro equipo, compuesto
                                                por personas apasionadas
                                                y comprometidas, ha sido
                                                clave en nuestro
                                                crecimiento. Desde el
                                                campo hasta el empaque
                                                final, cada miembro de
                                                Amazónica Foods trabaja
                                                con un solo objetivo en
                                                mente: ofrecer productos
                                                de la más alta calidad
                                                que epresenten lo mejor
                                                de la biodiversidad
                                                peruana. Cada fruta,
                                                cada grano y cada
                                                producto que exportamos
                                                es cuidadosamente
                                                seleccionado, asegurando
                                                que nuestros clientes
                                                reciban lo mejor del
                                                Perú.
                                            </p>
                                            <p>Con el esfuerzo conjunto
                                                de nuestros agricultores
                                                y colaboradores, hemos
                                                logrado consolidarnos
                                                como un referente en el
                                                mercado global,
                                                exportando productos que
                                                no solo cumplen con
                                                altos estándares de
                                                calidad, sino que
                                                también promueven el
                                                desarrollo sostenible y
                                                responsable.
                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="pg-250-1" class="panel-grid panel-no-style">
                            <div id="pgc-250-1-1" class="panel-grid-cell">
                                <div id="panel-250-1-1-0" class="so-panel widget widget_sow-image panel-first-child panel-last-child" data-index="2">
                                    <div class="so-widget-sow-image so-widget-sow-image-default-8b5b6f678277-250">

                                        <div class="sow-image-container">
                                            <img fetchpriority="high" decoding="async" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/single/machine.jpg" alt="Machine" width="800" height="600" sizes="(max-width: 800px) 100vw, 800px" alt class="so-widget-image">
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- AddThis Advanced Settings above via filter on the_content --><!-- AddThis Advanced Settings below via filter on the_content --><!-- AddThis Advanced Settings generic via filter on the_content --><!-- AddThis Share Buttons above via filter on the_content --><!-- AddThis Share Buttons below via filter on the_content -->
                    <div class="at-below-post-page addthis_tool" data-url="/"></div><!-- AddThis Share Buttons generic via filter on the_content -->
                </div>
            </div>
        </article>

    </div>

    <div class="section bg-white my-0   py-0">
        <div class="container-fluid py-5 " style="background: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/section-4.jpg') no-repeat 25% 100% / cover; background-attachment: fixed;">
            <div class="row justify-content-end align-items-md-center min-vh-60 mw-md">
                <div class="col-md-7 col-lg-5">
                    <p style="font-size: 1.5rem; color: #212529;" class="mb-2  ">Unimos
                        productores locales y clientes globales </p>

                    <h2 style="font-weight: 900;" class="display-4 text-transform-none ls-0 font-primary color">Únete
                        a
                        Nuestra Red Internacional</h2>
                    <div class="subscribe-widget" data-loader="button">
                        <div class="widget-subscribe-form-result"></div>

                        <?php echo do_shortcode('[shortcode_form_empresas]'); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

</main>
<!-- Main content End -->
<?php
get_footer();

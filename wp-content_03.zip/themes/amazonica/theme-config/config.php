<?php
function enqueue_header_styles_and_scripts()
{
    wp_enqueue_style('fontsgoogleapiscom', 'https://fonts.googleapis.com/css?family=Open+Sans:400,700', array(), null);
    wp_enqueue_style('MyFontsWebfontsKit.css', get_stylesheet_directory_uri() . '/assets/fonts/MyFontsWebfontsKit.css', array(), null);
    wp_enqueue_style('slick.css', get_stylesheet_directory_uri() . '/assets/slick/slick.css', array(), null);
    if (is_page('frutas')) {
        wp_enqueue_style('ghtml_css_frutas.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_frutas.css', array(), null);
    }
    if (is_page('fruta')) {
        wp_enqueue_style('ghtml_css_fruta.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_fruta.css', array(), null);
    }
    if (is_page('videos')) {
        wp_enqueue_style('ghtml_css_videos.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_videos.css', array(), null);
    }
    if (is_page('uva')) {
        wp_enqueue_style('ghtml_css_uva.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_uva.css', array(), null);
    }
    if (is_page('temp')) {
        wp_enqueue_style('ghtml_css_temp.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_temp.css', array(), null);
    }
    if (is_single()) {
        wp_enqueue_style('ghtml_css_single.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_single.css', array(), null);
    }
    if (is_page('palta')) {
        wp_enqueue_style('ghtml_css_palta.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_palta.css', array(), null);
    }
    if (is_page('nuestra-historia')) {
        wp_enqueue_style('ghtml_css_nuestra-historia.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_nuestra-historia.css', array(), null);
    }
    if (is_page('nosotros')) {
        wp_enqueue_style('ghtml_css_nosotros.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_nosotros.css', array(), null);
    }
    if (is_page('mision-vision')) {
        wp_enqueue_style('ghtml_css_mision-vision.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_mision-vision.css', array(), null);
    }
    if (is_page('mango')) {
        wp_enqueue_style('ghtml_css_mango.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_mango.css', array(), null);
    }
    if (is_page('limon')) {
        wp_enqueue_style('ghtml_css_limon.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_limon.css', array(), null);
    }
    if (is_page('kion')) {
        wp_enqueue_style('ghtml_css_kion.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_kion.css', array(), null);
    }
    if (is_page('exportaciones')) {
        wp_enqueue_style('ghtml_css_exportaciones.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_exportaciones.css', array(), null);
    }

    if (is_page('cerezas')) {
        wp_enqueue_style('ghtml_css_cerezas.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_cerezas.css', array(), null);
    }
    if (is_page('cafe')) {
        wp_enqueue_style('ghtml_css_cafe.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_cafe.css', array(), null);
    }
    if (is_page('cacao')) {
        wp_enqueue_style('ghtml_css_cacao.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_cacao.css', array(), null);
    }
    if (is_home()) {
        wp_enqueue_style('ghtml_css_blog.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_blog.css', array(), null);
    }
    if (is_page('banano')) {
        wp_enqueue_style('ghtml_css_banano.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_banano.css', array(), null);
    }
    if (is_page('arandanos')) {
        wp_enqueue_style('ghtml_css_arandanos.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_arandanos.css', array(), null);
    }
    if (is_post_type_archive('fruta')) {
        wp_enqueue_style('ghtml_css_fruta_archive.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_fruta_archive.css', array(), null);
    }
    if (is_singular('fruta')) {
        wp_enqueue_style('ghtml_css_fruta_single.css', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_fruta_single.css', array(), null);
    }
    wp_enqueue_style('style.css', get_stylesheet_directory_uri() . '/assets/camposol/style.css', array(), null);
    wp_enqueue_style('meanmenu.css', get_stylesheet_directory_uri() . '/assets/css/meanmenu.css', array(), null);
    wp_enqueue_style('fancybox.css', get_stylesheet_directory_uri() . '/assets/css/fancybox.css', array(), null);
    wp_enqueue_style('font-icons.css', get_stylesheet_directory_uri() . '/assets/css/font-icons.css', array(), null);
    wp_enqueue_style('style', get_stylesheet_directory_uri() . '/assets/style.css', array(), null);
    wp_enqueue_style('front-flex.mina1bb.css?ver=2.29.22', get_stylesheet_directory_uri() . '/assets/css/front-flex.mina1bb.css?ver=2.29.22', array(), null);
    wp_enqueue_style('custom.css', get_stylesheet_directory_uri() . '/assets/css/custom.css', array(), null);
    wp_enqueue_style('front-flex.mina1bb.css?ver=2.29.22', get_stylesheet_directory_uri() . '/assets/css/front-flex.mina1bb.css?ver=2.29.22', array(), null);
    wp_enqueue_script('jquery.min.js', get_stylesheet_directory_uri() . '///ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js', array('jquery'), null, false);
    wp_enqueue_script('jquery.min.js', get_stylesheet_directory_uri() . '///ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js', array('jquery'), null, false);
    if (is_page('contacto')) {
        wp_enqueue_style('ghtml_css_contacto', get_stylesheet_directory_uri() . '/assets/css/ghtml_css_contacto.css', array(), null);
    }
}
add_action('wp_enqueue_scripts', 'enqueue_header_styles_and_scripts');

function enqueue_footer_scripts()
{
    wp_enqueue_script('plugins.min.js', get_stylesheet_directory_uri() . '/assets/js/plugins.min.js', array('jquery'), null, true);
    wp_enqueue_script('functions.bundle.js', get_stylesheet_directory_uri() . '/assets/js/functions.bundle.js', array('jquery'), null, true);
    wp_enqueue_script('all.js', get_stylesheet_directory_uri() . '///use.fontawesome.com/releases/v5.0.6/js/all.js', array('jquery'), null, true);
    wp_enqueue_script('slick.min.js', get_stylesheet_directory_uri() . '/assets/js/slick/slick.min.js', array('jquery'), null, true);
    wp_enqueue_script('jquery.fancybox.min.js', get_stylesheet_directory_uri() . '/assets/js/fancybox/jquery.fancybox.min.js', array('jquery'), null, true);
    wp_enqueue_script('jquery.meanmenu.min.js', get_stylesheet_directory_uri() . '/assets/js/jquery.meanmenu.min.js', array('jquery'), null, true);
    wp_enqueue_script('script.js', get_stylesheet_directory_uri() . '/assets/js/script.js', array('jquery'), null, true);
    if (is_singular('fruta')) {
        wp_enqueue_script('ghtml_js_fruta_single.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_fruta_single.js', array('jquery'), null, true);
    }
    if (is_post_type_archive('fruta')) {
        wp_enqueue_script('ghtml_js_fruta_archive.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_fruta_archive.js', array('jquery'), null, true);
    }
    if (is_page('arandanos')) {
        wp_enqueue_script('ghtml_js_arandanos.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_arandanos.js', array('jquery'), null, true);
    }
    if (is_page('banano')) {
        wp_enqueue_script('ghtml_js_banano.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_banano.js', array('jquery'), null, true);
    }
    if (is_home()) {
        wp_enqueue_script('ghtml_js_blog.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_blog.js', array('jquery'), null, true);
    }
    if (is_page('cacao')) {
        wp_enqueue_script('ghtml_js_cacao.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_cacao.js', array('jquery'), null, true);
    }
    if (is_page('cafe')) {
        wp_enqueue_script('ghtml_js_cafe.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_cafe.js', array('jquery'), null, true);
    }
    if (is_page('cerezas')) {
        wp_enqueue_script('ghtml_js_cerezas.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_cerezas.js', array('jquery'), null, true);
    }
    if (is_page('contacto')) {
        wp_enqueue_script('ghtml_js_contacto.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_contacto.js', array('jquery'), null, true);
    }
    if (is_page('exportaciones')) {
        wp_enqueue_script('ghtml_js_exportaciones.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_exportaciones.js', array('jquery'), null, true);
    }
    if (is_page('kion')) {
        wp_enqueue_script('ghtml_js_kion.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_kion.js', array('jquery'), null, true);
    }
    if (is_page('limon')) {
        wp_enqueue_script('ghtml_js_limon.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_limon.js', array('jquery'), null, true);
    }
    if (is_page('mango')) {
        wp_enqueue_script('ghtml_js_mango.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_mango.js', array('jquery'), null, true);
    }
    if (is_page('mision-vision')) {
        wp_enqueue_script('ghtml_js_mision-vision.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_mision-vision.js', array('jquery'), null, true);
    }
    if (is_page('nosotros')) {
        wp_enqueue_script('ghtml_js_nosotros.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_nosotros.js', array('jquery'), null, true);
    }
    if (is_page('nuestra-historia')) {
        wp_enqueue_script('ghtml_js_nuestra-historia.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_nuestra-historia.js', array('jquery'), null, true);
    }
    if (is_page('palta')) {
        wp_enqueue_script('ghtml_js_palta.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_palta.js', array('jquery'), null, true);
    }
    if (is_single()) {
        wp_enqueue_script('ghtml_js_single.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_single.js', array('jquery'), null, true);
    }
    if (is_page('temp')) {
        wp_enqueue_script('ghtml_js_temp.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_temp.js', array('jquery'), null, true);
    }
    if (is_page('uva')) {
        wp_enqueue_script('ghtml_js_uva.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_uva.js', array('jquery'), null, true);
    }
    if (is_page('videos')) {
        wp_enqueue_script('ghtml_js_videos.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_videos.js', array('jquery'), null, true);
    }
    if (is_page('fruta')) {
        wp_enqueue_script('ghtml_js_fruta.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_fruta.js', array('jquery'), null, true);
    }
    if (is_page('frutas')) {
        wp_enqueue_script('ghtml_js_frutas.js', get_stylesheet_directory_uri() . '/assets/js/ghtml_js_frutas.js', array('jquery'), null, true);
    }
}
add_action('wp_footer', 'enqueue_footer_scripts');


// Funcion agregar categorias 
function agregar_categorias_blog()
{
    $categorias = array(
        0 => 'Seguros Sociales',
        1 => 'Seguros de Costa rica',
        2 => 'Otros Seguros',
    );
    foreach ($categorias as $categoria) {
        if (!term_exists($categoria, 'category')) {
            wp_insert_term($categoria, 'category');
        }
    }
}
add_action('init', 'agregar_categorias_blog');
//Fin de funcion agregar categoria

// Agregar soporte para imágenes destacadas 
function theme_setup()
{
    add_theme_support('post-thumbnails');
}
add_action('after_setup_theme', 'theme_setup');
// Fin agregar soporte para imágenes destacadas

// Función para personalizar la búsqueda 
function buscar_post($query)
{
    if ($query->is_search()) {
        $query->set('post_type', 'post');
    }
    return $query;
}
add_filter('pre_get_posts', 'buscar_post');
// Fin función para personalizar la búsqueda    

// Registro de dos áreas de menús de navegación
function menu()
{
    register_nav_menus(
        array(
            'left-menu' => __('Menú Izquierdo', 'text-domain'),
            'right-menu' => __('Menú Derecho', 'text-domain')
        )
    );
}
add_action('after_setup_theme', 'menu');

//Configuración de menú dinámico
function add_dynamic_menu_option()
{
    add_settings_section(
        'menu_settings_section', // ID
        'Configuración de Menú', // Title
        null, // Callback
        'general' // Page
    );

    add_settings_field(
        'is_active_menu', // ID
        'Menu Dinámico Activo', // Title
        'is_active_menu_callback', // Callback
        'general', // Page
        'menu_settings_section' // Section
    );

    register_setting('general', 'is_active_menu', array(
        'type' => 'boolean',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => false
    ));
}
add_action('admin_init', 'add_dynamic_menu_option');

function is_active_menu_callback()
{
    $checked = get_option('is_active_menu') ? 'checked' : '';
    echo '<input type="checkbox" id="is_active_menu" name="is_active_menu" value="1" ' . $checked . ' />';
}

// Crear páginas personalizadas y configurar página de inicio y de entradas al activar el tema
function create_custom_pages()
{
    if (get_option('custom_theme_auto_regenerate_pages') != 1) {
        return;
    }
    $pageTitles = array(
        0 => 'blog',
        1 => 'arandanos',
        2 => 'banano',
        3 => 'cacao',
        4 => 'cafe',
        5 => 'cerezas',
        6 => 'contacto',
        7 => 'exportaciones',
        8 => 'home',
        9 => 'kion',
        10 => 'limon',
        11 => 'mango',
        12 => 'mision-vision',
        13 => 'nosotros',
        14 => 'nuestra-historia',
        15 => 'palta',
        16 => 'temp',
        17 => 'uva',
        18 => 'videos',
    );
    $ids = [];
    foreach ($pageTitles as $page_title) {
        $args = ['post_type' => 'page', 'post_status' => 'publish', 'title' => $page_title, 'posts_per_page' => 1];
        $query = new WP_Query($args);
        if (!$query->have_posts()) {
            $ids[$page_title] = wp_insert_post(['post_title' => $page_title, 'post_type' => 'page', 'post_status' => 'publish']);
        } else {
            $query->the_post();
            $ids[$page_title] = get_the_ID();
        }
        wp_reset_postdata();
    }
    // Ejemplo para configurar 'Home' como página de inicio
    if (get_option('mytheme_setup_completed') !== 'yes') {
        if (isset($ids['home'])) {
            update_option('show_on_front', 'page');
            update_option('page_on_front', $ids['home']);
        }
        if (isset($ids['blog'])) {
            update_option('page_for_posts', $ids['blog']);
        }
        // Marcar la configuración inicial como completada
        update_option('mytheme_setup_completed', 'yes');
    }
}
add_action('after_setup_theme', 'create_custom_pages');

// Nueva funcionalidad de páginas creadas
function my_custom_theme_page_menu()
{
    add_menu_page(
        'Gestión de Páginas Automáticas',
        'Páginas Automáticas',
        'manage_options',
        'custom-theme-page-management',
        'custom_theme_options_page',
        'dashicons-admin-page',
        20
    );
}
add_action('admin_menu', 'my_custom_theme_page_menu');

function custom_theme_options_page()
{
?>
    <div class="wrap">
        <h2>Gestión de Páginas Automáticas</h2>
        <form method="post" action="options.php">
            <?php
            settings_fields('custom_theme_page_settings');
            do_settings_sections('custom-theme-page-management');
            submit_button('Guardar Cambios');
            ?>
        </form>
    </div>
<?php
}

function custom_theme_settings_init()
{
    register_setting('custom_theme_page_settings', 'custom_theme_auto_regenerate_pages');

    add_settings_section(
        'custom_theme_page_settings_section',
        'Configuraciones de Páginas Automáticas',
        'custom_theme_page_settings_section_cb',
        'custom-theme-page-management'
    );

    add_settings_field(
        'custom_theme_auto_regenerate_pages_field',
        'Regenerar Páginas Automáticamente',
        'custom_theme_auto_regenerate_pages_field_cb',
        'custom-theme-page-management',
        'custom_theme_page_settings_section'
    );
}
add_action('admin_init', 'custom_theme_settings_init');

function set_default_auto_regenerate_pages()
{
    add_option('custom_theme_auto_regenerate_pages', '1'); // Asegura que la opción esté marcada por defecto
}
add_action('after_switch_theme', 'set_default_auto_regenerate_pages');

function custom_theme_page_settings_section_cb()
{
    echo '<p>Seleccione si desea que las páginas se regeneren automáticamente después de ser eliminadas.</p>';
}

function custom_theme_auto_regenerate_pages_field_cb()
{
    $option = get_option('custom_theme_auto_regenerate_pages', '1');
    echo '<input type="checkbox" id="custom_theme_auto_regenerate_pages" name="custom_theme_auto_regenerate_pages" value="1"' . checked(1, $option, false) . '>';
}

add_action('admin_init', 'custom_theme_settings_init');




//Dar soporte a title: ideal para plugins de SEO
function theme_slug_setup()
{
    add_theme_support('title-tag');
}
add_action('after_setup_theme', 'theme_slug_setup');



// Añade soporte para Site Icon

function mytheme_setup()
{
    add_theme_support('site-icon');
}
add_action('after_setup_theme', 'mytheme_setup');



// Añadir soporte para logo personalizado
function mytheme_setup_logo()
{
    // Soporte para logo personalizado
    add_theme_support('custom-logo', array(
        'height'      => 100, // Ajusta según tus necesidades
        'width'       => 400, // Ajusta según tus necesidades
        'flex-height' => true,
        'flex-width'  => true,
    ));
}
add_action('after_setup_theme', 'mytheme_setup_logo');

//Configuración de datos de la empresa
// Paso 1: Registrar en el dashboard
function my_custom_theme_menu()
{
    add_menu_page('Datos de empresa', 'Datos de empresa', 'manage_options', 'theme-options', 'my_custom_theme_options_page');
}
add_action('admin_menu', 'my_custom_theme_menu');

// Paso 2: Registrar datos
function my_custom_theme_options_page()
{
?>
    <div class="wrap">
        <h2>Datos de empresa</h2>
        <form method="post" action="options.php">
            <?php
            settings_fields('section');
            do_settings_sections('theme-options');
            submit_button();
            ?>
        </form>
    </div>
<?php
}

// Funciones de retorno para company, address, y whatsapp
function setting_company()
{
    echo '<input type="text" name="company" id="company" value="' . get_option('company') . '" />';
}

function setting_address()
{
    echo '<textarea name="address" id="address" rows="4" cols="50">' . esc_textarea(get_option('address')) . '</textarea>';
}

function setting_whatsapp()
{
    echo '<input type="text" name="whatsapp" id="whatsapp" value="' . get_option('whatsapp') . '" />';
}

function setting_phone()
{
    echo '<input type="text" name="phone" id="phone" value="' . esc_attr(get_option('phone')) . '" />';
}

function setting_email()
{
    echo '<input type="email" name="email" id="email" value="' . esc_attr(get_option('email')) . '" />';
}

function setting_facebook()
{
    echo '<input type="text" name="facebook" id="facebook" value="' . esc_attr(get_option('facebook')) . '" />';
}
function setting_instagram()
{
    echo '<input type="text" name="instagram" id="instagram" value="' . esc_attr(get_option('instagram')) . '" />';
}
function setting_x()
{
    echo '<input type="text" name="x" id="x" value="' . esc_attr(get_option('x')) . '" />';
}
function setting_youtube()
{
    echo '<input type="text" name="youtube" id="youtube" value="' . esc_attr(get_option('youtube')) . '" />';
}
function setting_linkedin()
{
    echo '<input type="text" name="linkedin" id="linkedin" value="' . esc_attr(get_option('linkedin')) . '" />';
}
function setting_tiktok()
{
    echo '<input type="text" name="tiktok" id="tiktok" value="' . esc_attr(get_option('tiktok')) . '" />';
}
// Agregar las funciones de redes sociales

// Paso 4: Registrar estos inputs de configuración
function display_theme_panel_fields()
{
    add_settings_section('section', 'Configuraciones Básicas', null, 'theme-options');
    add_settings_field('company', 'Nombre de la Empresa', 'setting_company', 'theme-options', 'section');
    add_settings_field('address', 'Dirección', 'setting_address', 'theme-options', 'section');
    add_settings_field('whatsapp', 'WhatsApp', 'setting_whatsapp', 'theme-options', 'section');
    add_settings_field('phone', 'Phone', 'setting_phone', 'theme-options', 'section');
    register_setting('section', 'phone');
    add_settings_field('email', 'Email', 'setting_email', 'theme-options', 'section');
    register_setting('section', 'email');
    // Agregar los campos de registro dinámicos para teléfono y correo electrónico
    register_setting('section', 'company');
    register_setting('section', 'address');
    register_setting('section', 'whatsapp');

    add_settings_field('facebook', 'facebook', 'setting_facebook', 'theme-options', 'section');
    register_setting('section', 'facebook');
    add_settings_field('instagram', 'instagram', 'setting_instagram', 'theme-options', 'section');
    register_setting('section', 'instagram');
    add_settings_field('x', 'x', 'setting_x', 'theme-options', 'section');
    register_setting('section', 'x');
    add_settings_field('youtube', 'youtube', 'setting_youtube', 'theme-options', 'section');
    register_setting('section', 'youtube');
    add_settings_field('linkedin', 'linkedin', 'setting_linkedin', 'theme-options', 'section');
    register_setting('section', 'linkedin');
    add_settings_field('tiktok', 'tiktok', 'setting_tiktok', 'theme-options', 'section');
    register_setting('section', 'tiktok');
    // Agregar los campos de registro dinámicos para redes sociales
}
add_action('admin_init', 'display_theme_panel_fields');

// Paso 5: Mensaje de alerta de éxito o fracaso
add_action('admin_notices', 'my_admin_notice');
function my_admin_notice()
{
?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e('Cambios guardados exitosamente.', 'text-domain'); ?></p>
    </div>
<?php
}


// Register Custom Post Type: fruta
// Registrar el Custom Post Type Fruta
// Registrar el Custom Post Type Fruta
function register_cpt_fruta()
{
    $args = array(
        'public' => true,
        'has_archive' => 'frutas',
        'rewrite' => array('slug' => 'frutas'),
        'labels' => array('name' => 'Frutas', 'singular_name' => 'Fruta'),
        'supports' => array('title', 'editor', 'thumbnail'),
    );
    register_post_type('fruta', $args);
}
add_action('init', 'register_cpt_fruta');

// Agregar el Meta Box para Fruta
function add_meta_box_fruta_info()
{
    add_meta_box('fruta_info', 'Frutas Información', 'display_meta_box_fruta_info', 'fruta', 'advanced', 'default');
}
add_action('add_meta_boxes', 'add_meta_box_fruta_info');

// Mostrar el metabox con inputs para cargar imágenes y otros campos
function display_meta_box_fruta_info($post) {
    wp_nonce_field('save_meta_box_fruta_info_data', 'fruta_info_nonce');

    // Inputs para subir imágenes, ahora incluyendo imagen_4
    $imagenes = ['imagen_1', 'imagen_2', 'imagen_3', 'imagen_4'];
    foreach ($imagenes as $imagen) {
        $imagen_url = get_post_meta($post->ID, $imagen, true);

        echo "<label for='{$imagen}'>{$imagen}:</label><br />";
        echo "<input type='file' id='{$imagen}' name='{$imagen}' accept='image/*' /><br />";

        if ($imagen_url) {
            echo "<img src='" . esc_url($imagen_url) . "' style='max-width: 100px; height: auto;' /><br />";
        }
        echo "<br />";
    }

    // Campos de texto adicionales
    $campos_texto = [
        'titulo' => 'Titulo',
        'descripcion' => 'Descripcion',
        'titulo_cultivo' => 'Titulo Cultivo',
        'subitulo_cultivo' => 'Subitulo Cultivo',
        'preparacion' => 'Preparacion',
        'cultivo' => 'Cultivo',
        'consecha' => 'Consecha',
        'post_cosecha' => 'Post Cosecha',
        'remate_cultivos' => 'Remate Cultivos'
    ];
    
    foreach ($campos_texto as $campo_id => $campo_label) {
        $campo_valor = get_post_meta($post->ID, $campo_id, true);
        echo "<label for='{$campo_id}'>{$campo_label}:</label><br />";
        echo "<input type='text' id='{$campo_id}' name='{$campo_id}' value='" . esc_attr($campo_valor) . "' class='widefat' />";
        echo "<br /><br />";
    }
}

// Guardar los datos del metabox incluyendo las imágenes
function save_meta_box_fruta_info_data($post_id) {
    // Verificar nonce
    if (!isset($_POST['fruta_info_nonce']) || !wp_verify_nonce($_POST['fruta_info_nonce'], 'save_meta_box_fruta_info_data')) {
        return;
    }

    // Evitar autosaves
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Verificar permisos
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    // Guardar imágenes, ahora incluyendo imagen_4
    $imagenes = ['imagen_1', 'imagen_2', 'imagen_3', 'imagen_4'];
    foreach ($imagenes as $imagen) {
        if (!empty($_FILES[$imagen]['name'])) {
            $attachment_id = media_handle_upload($imagen, $post_id);
            if (is_wp_error($attachment_id)) {
                error_log("Error al subir $imagen: " . $attachment_id->get_error_message());
            } else {
                // Guardar la URL de la imagen
                $image_url = wp_get_attachment_url($attachment_id);
                if ($image_url) {
                    update_post_meta($post_id, $imagen, $image_url);
                }
            }
        }
    }

    // Guardar campos de texto
    $campos_texto = [
        'titulo', 'descripcion', 'titulo_cultivo', 'subitulo_cultivo',
        'preparacion', 'cultivo', 'consecha', 'post_cosecha', 'remate_cultivos'
    ];
    foreach ($campos_texto as $campo) {
        if (array_key_exists($campo, $_POST)) {
            $sanitized_value = sanitize_text_field($_POST[$campo]);
            update_post_meta($post_id, $campo, $sanitized_value);
        }
    }
}
add_action('save_post', 'save_meta_box_fruta_info_data');


// Asegurar el enctype en el formulario de edición de publicaciones
function agregar_enctype_multipart() {
    echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            const postForm = document.getElementById("post");
            if (postForm) {
                postForm.setAttribute("enctype", "multipart/form-data");
            }
        });
    </script>';
}
add_action('edit_form_advanced', 'agregar_enctype_multipart');



// Custom exportaciones 

function register_cpt_exportaciones() {
    $labels = array (
  'name' => 'Exportacioness',
  'singular_name' => 'Exportaciones',
  'add_new' => 'Add New',
  'add_new_item' => 'Add New Exportaciones',
  'edit_item' => 'Edit Exportaciones',
  'new_item' => 'New Exportaciones',
  'view_item' => 'View Exportaciones',
  'search_items' => 'Search Exportacioness',
  'not_found' => 'No Exportacioness found',
  'not_found_in_trash' => 'No Exportacioness found in Trash',
  'parent_item_colon' => '',
  'menu_name' => 'Exportacioness',
  'show_in_rest' => true,
);
    $args = array(
        'public' => true,
        'has_archive' => false,
        'supports' => array('title', 'editor', 'thumbnail'),
        'labels' => $labels,
    );
    register_post_type('exportaciones', $args);
}
add_action('init', 'register_cpt_exportaciones');

// Add Meta Box for exportaciones
function add_meta_box_exportaciones_meta() {
    add_meta_box('exportaciones_meta', 'exportaciones Meta', 'display_meta_box_exportaciones_meta', 'exportaciones', 'advanced', 'default');
}
add_action('add_meta_boxes', 'add_meta_box_exportaciones_meta');

function display_meta_box_exportaciones_meta($post) {
    wp_nonce_field('save_meta_box_exportaciones_meta_data', 'exportaciones_meta_nonce');

    
    $is_active = get_post_meta($post->ID, 'is_active', true);
    $checked = ($is_active == '1') ? 'checked' : '';
    
    // Meta box display callback.
    echo <<<HTML
    
    <div style="margin-top: 10px">
        <label for="is_active">Activo:</label>
        <input style="margin-top: 1px" type="checkbox" id="is_active" name="is_active" value="1" {$checked} /><br />
    </div>
HTML;     
}

function save_meta_box_exportaciones_meta_data($post_id) {
     

   if (!isset($_POST['exportaciones_meta_nonce']) || !wp_verify_nonce($_POST['exportaciones_meta_nonce'], 'save_meta_box_exportaciones_meta_data')) {
    return;
    }

    

     // If this is an autosave, our form has not been submitted.
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

     // Check the user's permissions.
    if (isset($_POST['post_type']) && $_POST['post_type'] === "exportaciones") {
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
    }


    // Actual save logic for each field
    


     // Guardar el estado del checkbox de "Activo"
    $is_active = isset($_POST['is_active']) ? '1' : '0';
    update_post_meta($post_id, 'is_active', $is_active);
   
}
add_action('save_post', 'save_meta_box_exportaciones_meta_data');

   
// Fin de exportaciones 







//Custom para los videos


//Soporte el código para registrar el Custom Post Type Simples e iterables sin internas

// Prinera funcion 
function register_cpt_videos() {
    $labels = array (
  'name' => 'Videoss',
  'singular_name' => 'Videos',
  'add_new' => 'Add New',
  'add_new_item' => 'Add New Videos',
  'edit_item' => 'Edit Videos',
  'new_item' => 'New Videos',
  'view_item' => 'View Videos',
  'search_items' => 'Search Videoss',
  'not_found' => 'No Videoss found',
  'not_found_in_trash' => 'No Videoss found in Trash',
  'parent_item_colon' => '',
  'menu_name' => 'Videoss',
  'show_in_rest' => true,
);
    $args = array(
        'public' => true,
        'has_archive' => false,
        'supports' => array('title', 'editor', 'thumbnail'),
        'labels' => $labels,
    );
    register_post_type('videos', $args);
}
add_action('init', 'register_cpt_videos');


// Segunda funcion 
// Add Meta Box for videos
function add_meta_box_videos_meta() {
    add_meta_box('videos_meta', 'videos Meta', 'display_meta_box_videos_meta', 'videos', 'advanced', 'default');
}
add_action('add_meta_boxes', 'add_meta_box_videos_meta');


// Tercera funcion 
function display_meta_box_videos_meta($post) {
    wp_nonce_field('save_meta_box_videos_meta_data', 'videos_meta_nonce');

    $enlace_youtube = get_post_meta($post->ID, 'enlace_youtube', true);
$duracion = get_post_meta($post->ID, 'duracion', true);

    $is_active = get_post_meta($post->ID, 'is_active', true);
    $checked = ($is_active == '1') ? 'checked' : '';
    
    // Meta box display callback.
    echo <<<HTML
    <label for="Enlace_youtube">Enlace youtube:</label><br />
<input type="text" id="Enlace_youtube" name="Enlace_youtube" class="widefat" value="$enlace_youtube" /><br /><br />

<label for="Duracion">Duracion:</label><br />
<input type="text" id="Duracion" name="Duracion" class="widefat" value="$duracion" /><br /><br />


    <div style="margin-top: 10px">
        <label for="is_active">Activo:</label>
        <input style="margin-top: 1px" type="checkbox" id="is_active" name="is_active" value="1" {$checked} /><br />
    </div>
HTML;  

}

// Cuarta 
function save_meta_box_videos_meta_data($post_id) {
     

   if (!isset($_POST['videos_meta_nonce']) || !wp_verify_nonce($_POST['videos_meta_nonce'], 'save_meta_box_videos_meta_data')) {
    return;
    }

    

     // If this is an autosave, our form has not been submitted.
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

     // Check the user's permissions.
    if (isset($_POST['post_type']) && $_POST['post_type'] === "videos") {
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
    }


    // Actual save logic for each field
    
    if (array_key_exists('Enlace_youtube', $_POST)) {
        $sanitized_value = sanitize_text_field($_POST['Enlace_youtube']);
        update_post_meta($post_id, 'enlace_youtube', $sanitized_value);
    }
    if (array_key_exists('Duracion', $_POST)) {
        $sanitized_value = sanitize_text_field($_POST['Duracion']);
        update_post_meta($post_id, 'duracion', $sanitized_value);
    }


     // Guardar el estado del checkbox de "Activo"
    $is_active = isset($_POST['is_active']) ? '1' : '0';
    update_post_meta($post_id, 'is_active', $is_active);
   
}
add_action('save_post', 'save_meta_box_videos_meta_data');    

// Culmina Videos 
// Fin de custom para los videos



//Soporte para las secciones internas: nosotros

// Soporte Nosotros - Custom Post Type para "Nosotros"
function register_cpt_nosotros() {
    $labels = array (
        'name' => 'Nosotross',
        'singular_name' => 'Nosotros',
        'add_new' => 'Add New',
        'add_new_item' => 'Add New Nosotros',
        'edit_item' => 'Edit Nosotros',
        'new_item' => 'New Nosotros',
        'view_item' => 'View Nosotros',
        'search_items' => 'Search Nosotross',
        'not_found' => 'No Nosotross found',
        'not_found_in_trash' => 'No Nosotross found in Trash',
        'parent_item_colon' => '',
        'menu_name' => 'Nosotross',
        'show_in_rest' => true,
    );

    $args = array(
        'public' => true,
        'has_archive' => false,
        'supports' => array('title', 'editor', 'thumbnail'),
        'labels' => $labels,
    );

    register_post_type('nosotros', $args);
}
add_action('init', 'register_cpt_nosotros');

// Añadir Meta Box para "Nosotros"
function add_meta_box_nosotros_meta() {
    add_meta_box('nosotros_meta', 'nosotros Meta', 'display_meta_box_nosotros_meta', 'nosotros', 'advanced', 'default');
}
add_action('add_meta_boxes', 'add_meta_box_nosotros_meta');

// Mostrar Meta Box de "Nosotros"
function display_meta_box_nosotros_meta($post) {
    wp_nonce_field('save_meta_box_nosotros_meta_data', 'nosotros_meta_nonce');

    $is_active = get_post_meta($post->ID, 'is_active', true);
    $checked = ($is_active == '1') ? 'checked' : '';

    echo <<<HTML
    <div style="margin-top: 10px">
        <label for="is_active">Activo:</label>
        <input style="margin-top: 1px" type="checkbox" id="is_active" name="is_active" value="1" {$checked} /><br />
    </div>
HTML;
}

// Guardar Meta Data de "Nosotros"
function save_meta_box_nosotros_meta_data($post_id) {
    if (!isset($_POST['nosotros_meta_nonce']) || !wp_verify_nonce($_POST['nosotros_meta_nonce'], 'save_meta_box_nosotros_meta_data')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (isset($_POST['post_type']) && $_POST['post_type'] === "nosotros") {
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
    }

    // Guardar el estado del checkbox "Activo"
    $is_active = isset($_POST['is_active']) ? '1' : '0';
    update_post_meta($post_id, 'is_active', $is_active);
}
add_action('save_post', 'save_meta_box_nosotros_meta_data');


//fin de secciones internas: nosotros

// Custopm post type manager  
add_action('admin_menu', 'group_custom_post_types_in_admin_menu');


function group_custom_post_types_in_admin_menu()
{
    // Obtener todos los CPTs personalizados (que no sean los predeterminados de WP)
    $custom_post_types = get_post_types(['_builtin' => false], 'objects');

    // Si hay más de 2 CPTs personalizados, crear el menú "CPT Manager"
    if (count($custom_post_types) > 2) {
        // Crear el menú "CPT Manager"
        add_menu_page(
            'Gestor de Custom Post Types',
            'CPT Manager',
            'manage_options',
            'cpt-manager',
            'cpt_manager_page_content',    // Función que mostrará el contenido en la página principal
            'dashicons-awards',
            6
        );

        // Añadir los CPTs filtrados al "CPT Manager"
        foreach ($custom_post_types as $post_type) {
            add_submenu_page(
                'cpt-manager',
                $post_type->label,
                $post_type->label,
                'manage_options',
                'edit.php?post_type=' . $post_type->name
            );
        }

        // Añadir el "Datos de Empresa" también en el "CPT Manager"
        add_submenu_page(
            'cpt-manager',            // Menú principal (CPT Manager)
            'Datos de Empresa',        // Título en la página del submenú
            'Datos de Empresa',        // Texto del submenú
            'manage_options',          // Permiso requerido
            'theme-options',           // Slug de la página
            'my_custom_theme_options_page' // Función que mostrará el contenido
        );

        // Remover todos los CPTs personalizados y "Datos de Empresa" del menú lateral
        remove_registered_cpts_from_sidebar($custom_post_types);
        remove_menu_page('theme-options'); // Remover "Datos de Empresa" del menú lateral
    }
}

// Remover todos los CPTs del menú lateral principal
function remove_registered_cpts_from_sidebar($custom_post_types)
{
    foreach ($custom_post_types as $post_type) {
        remove_menu_page('edit.php?post_type=' . $post_type->name);
    }
}

//  Cpt Manager Section Promo
function cpt_manager_page_content()
{
?>
    <div class="wrap">
        <h1>Bienvenido a CPT Manager</h1>
        <p>Descubre nuestras últimas implementaciones y ofertas</p>

        <div style="display: flex; justify-content: space-between; gap: 20px;">
            <!-- Primera columna -->
            <div style="border: 2px dashed #ccc; width: 30%; padding: 20px; display: flex; flex-direction: column; align-items: center;">
                <span style="font-size: 16px; color: #999;">Tu Imagen Aquí</span>
                <p>
                    <a href="#" class="button button-primary" style="background-color: #0073aa; color: white; padding: 10px 20px; font-size: 16px; margin-top: 20px;">Comprar este Producto</a>
                </p>
            </div>

            <!-- Segunda columna -->
            <div style="border: 2px dashed #ccc; width: 30%; padding: 20px; display: flex; flex-direction: column; align-items: center;">
                <span style="font-size: 16px; color: #999;">Tu Imagen Aquí</span>
                <p>
                    <a href="#" class="button button-primary" style="background-color: #0073aa; color: white; padding: 10px 20px; font-size: 16px; margin-top: 20px;">Comprar este Producto</a>
                </p>
            </div>

            <!-- Tercera columna -->
            <div style="border: 2px dashed #ccc; width: 30%; padding: 20px; display: flex; flex-direction: column; align-items: center;">
                <span style="font-size: 16px; color: #999;">Tu Imagen Aquí</span>
                <p>
                    <a href="#" class="button button-primary" style="background-color: #0073aa; color: white; padding: 10px 20px; font-size: 16px; margin-top: 20px;">Comprar este Producto</a>
                </p>
            </div>
        </div>
    </div>
<?php
}



//Soporte para formularios 
function handle_empresas_submission()
{
    if (!isset($_POST['empresas_form_nonce']) || !wp_verify_nonce($_POST['empresas_form_nonce'], 'empresas_form')) {
        wp_send_json_error('Nonce verification failed.');
        return;
    }

    // Sanitizar campos

    $empresa = sanitize_text_field($_POST['empresa']);
    $email = sanitize_email($_POST['email']);
    $register_form_submit = sanitize_text_field($_POST['register_form_submit']);

    // Depurar datos antes de la inserción
    error_log('Datos a insertar: ' . print_r([
        'empresa' => $empresa,
        'email' => $email,
        'register_form_submit' => $register_form_submit,
        'created_at' => current_time('mysql')
    ], true));

    // Insertar datos en una tabla personalizada
    global $wpdb;
    $table_name = $wpdb->prefix . 'empresas_entries';
    error_log('Nombre de la tabla: ' . $table_name);  // Añadir un registro para el nombre de la tabla

    $result = $wpdb->insert(
        $table_name,
        [
            'empresa' => $empresa,
            'email' => $email,
            'register_form_submit' => $register_form_submit,
            'created_at' => current_time('mysql')
        ]
    );

    // Depurar el resultado de la inserción
    if ($result === false) {
        error_log('Error de inserción: ' . $wpdb->last_error);
        wp_send_json_error('Failed to insert data: ' . $wpdb->last_error);
    } else {
        wp_send_json_success('Form submitted successfully.');
    }
}
add_action('wp_ajax_nopriv_handle_empresas_submission', 'handle_empresas_submission');
add_action('wp_ajax_handle_empresas_submission', 'handle_empresas_submission');


function shortcode_form_empresas_form_shortcode()
{
    ob_start();
?>
    <form id="empresasForm" name="login-form" class="row mb-0" action="#" method="post">
        <div class="col-12 form-group">
            <input type="text" id="register_form_name" name="empresa" autocomplete="off" value class="form-control required" placeholder="Empresa">
        </div>

        <div class="col-12 form-group">
            <input type="email" id="register_form_email" name="email" autocomplete="off" value class="required email form-control" placeholder="Email">
        </div>

        <div class="col-12">
            <input type="submit" class="button m-0 w-100" id="register_form_submit" value="Enviar" name="register_form_submit">

        </div>
        <input type="hidden" name="action" value="handle_empresas_submission"><input type="hidden" name="empresas_form_nonce" value='<?php echo wp_create_nonce("empresas_form"); ?>'>
    </form>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <script>
    jQuery(document).ready(function($) {
        $("#empresasForm").submit(function(event) {
            event.preventDefault();

            // Validar campos requeridos antes de enviar
            var isValid = true;
            $(this).find(".required").each(function() {
                if ($.trim($(this).val()) === "") {
                    isValid = false;
                    $(this).addClass("error"); // Agregar una clase de error para indicar el campo vacío
                } else {
                    $(this).removeClass("error");
                }
            });

            // Mostrar mensaje de error si algún campo está vacío
            if (!isValid) {
                showToast('No se puede enviar. Por favor, complete todos los campos requeridos.', 'error');
                return; // Salir de la función si hay campos vacíos
            }

            // Si todos los campos están llenos, continuar con el envío AJAX
            var formData = $(this).serialize(); // Serializar los datos del formulario

            $.ajax({
                url: "<?php echo admin_url("admin-ajax.php"); ?>", // URL del admin-ajax.php para manejar la solicitud
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        // Verificamos si la página de confirmación existe haciendo una solicitud HEAD
                        var thankYouPageUrl = "<?php echo site_url('/confirm'); ?>";

                        $.ajax({
                            url: thankYouPageUrl,
                            type: 'HEAD',
                            success: function() {
                                $("#empresasForm")[0].reset(); // Limpiar los campos del formulario
                                window.location.href = thankYouPageUrl; // Redirigir si la página existe
                            },
                            error: function() {
                                showToast('Datos enviados con éxito.', 'success');
                                $("#empresasForm")[0].reset(); // Limpiar los campos del formulario
                            }
                        });
                    } else {
                        showToast('Error al insertar los datos: ' + response.data, 'error');
                    }
                },
                error: function() {
                    showToast('Hubo un problema al procesar el formulario.', 'error');
                }
            });
        });

        // Función para mostrar el toast nativo de WordPress con estilo mejorado
        function showToast(message, type) {
            var toastClass = (type === 'success') ? 'notice-success' : 'notice-error';
            var toast = `
                 <div class="notice ` + toastClass + ` is-dismissible" style="position: fixed; bottom: 20px; left: 20px; z-index: 9999; max-width: 300px; background: #d1e7dd; border-left: 4px solid #0a3622; border-top: 1px solid #0a3622; border-bottom: 1px solid #0a3622; border-right: 1px solid #0a3622; border-radius: 4px; padding: 15px 10px 5px 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <p style="color: ` + (type === 'success' ? '#0a3622' : '#a32121') + `!important; font-size: 14px; font-weight: 500">` + message + `</p>
            </div>
            `;
            $('body').append(toast);

            // Permitir cerrar el toast manualmente
            $('.notice.is-dismissible').on('click', '.notice-dismiss', function() {
                $(this).parent().remove();
            });

            // Desaparecer automáticamente después de 5 segundos
            setTimeout(function() {
                $('.notice').fadeOut(function() {
                    $(this).remove();
                });
            }, 3000);
        }
    });
    </script>
<?php
    return ob_get_clean();
}
add_shortcode('shortcode_form_empresas', 'shortcode_form_empresas_form_shortcode');

function register_empresas_menu_page()
{
    // Verifica si el usuario tiene los permisos necesarios
if (!current_user_can('manage_options')) {
    return;
}
    add_menu_page(
        'Empresas Entries',
        'Entradas form Empresas',
        'manage_options',
        'empresas',
        'empresas_page',
        'dashicons-list-view',
        6
    );
}
add_action('admin_menu', 'register_empresas_menu_page');

 

function empresas_page()
{
    if (!current_user_can('manage_options')) {
        return; // Restringe el acceso a la página administrativa de clientes
    }
    // // Muestra el contenido de la página
    contact_form_empresas_page();
}

function contact_form_empresas_page()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    global $wpdb;
    $slug = 'empresas';
    $table_name = $wpdb->prefix . $slug . '_entries';

    // Configurar la paginación
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 10; // Número de entradas por página
    $offset = ($paged - 1) * $per_page;

    // Obtener el total de entradas
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");

    // Obtener las entradas con límite y desplazamiento para la paginación
    $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name LIMIT %d OFFSET %d", $per_page, $offset));

    echo '<h1>Entradas de Formulario ' . esc_html('Empresas') . '</h1>';

    // Agregar estilo en línea para los botones
    echo '<style> .form-buttons { display: flex; gap: 10px; margin-bottom: 10px; } </style>';

    // Verificar si hay datos para mostrar
    if ($total > 0) {
        echo '<div class="form-buttons">';

        // Formulario para descargar CSV
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="download_empresas_form_csv">';
        wp_nonce_field('download_csv_nonce', 'download_csv_nonce_field');
        echo '<input type="submit" name="download_csv" value="Download CSV" class="button button-primary">';
        echo '</form>';

        // Formulario para eliminar todas las entradas
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="delete_all_empresas">';
        wp_nonce_field('delete_all_empresas_nonce', 'delete_all_empresas_nonce_field');
        echo '<input type="submit" name="delete_all_empresas" value="Eliminar todo" class="button button-danger" onclick="return confirm(\'¿Deseas eliminar todas las entradas?\');">';
        echo '</form>';

        echo '</div>';
    } else {
        echo '<p>No hay datos para descargar.</p>';
    }

    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr>';
    echo '<th>' . esc_html(ucfirst('empresa')) . '</th>';
    echo '<th>' . esc_html(ucfirst('email')) . '</th>';
    echo '<th>' . esc_html(ucfirst('register_form_submit')) . '</th>';
    echo '<th>Date</th>'; // Suponiendo que siempre hay una columna de fecha
    echo '</tr></thead>';
    echo '<tbody>';

    // Crear las filas de la tabla dinámicamente
    foreach ($results as $row) {
        echo '<tr>';
        echo '<td>' . esc_html($row->empresa) . '</td>';
        echo '<td>' . esc_html($row->email) . '</td>';
        echo '<td>' . esc_html($row->register_form_submit) . '</td>';
        echo '<td>' . esc_html($row->created_at) . '</td>'; // Columna de fecha
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';

    // Paginador
    $page_links = paginate_links([
        'base' => add_query_arg('paged', '%#%'),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($total / $per_page),
        'current' => $paged
    ]);

    if ($page_links) {
        echo '<div style="left: 0; position: absolute;" class="tablenav"><div class="tablenav-pages">' . $page_links . '</div></div>';
    }
}

// Función para manejar la eliminación de todos los datos
function delete_all_empresas()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['delete_all_empresas']) && check_admin_referer('delete_all_empresas_nonce', 'delete_all_empresas_nonce_field')) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'empresas_entries';

        $wpdb->query("DELETE FROM $table_name");

        wp_redirect(admin_url('admin.php?page=empresas'));
        exit;
    }
}
add_action('admin_post_delete_all_empresas', 'delete_all_empresas');


function create_empresas_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'empresas_entries';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        empresa text NOT NULL,
        email varchar(255) NOT NULL,
        register_form_submit text NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    // Verifica si la tabla se ha creado
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        error_log("Error: la tabla $table_name no se creó.");
    }
}
add_action('after_setup_theme', 'create_empresas_table');
function download_empresas_form_csv()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['download_csv']) && check_admin_referer('download_csv_nonce', 'download_csv_nonce_field')) {
        global $wpdb;
        $slug = 'empresas';
        $table_name = $wpdb->prefix . $slug . '_entries';
        $results = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

        if (empty($results)) {
            return;
        }

        $filename = 'empresas_entries_' . date('Y-m-d') . '.csv';

        // Iniciar el buffer de salida
        ob_start();

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename=' . $filename);

        $output = fopen('php://output', 'w');
        fputcsv($output, ['Empresa', 'Email', 'Register_form_submit', 'Date']);
        foreach ($results as $row) {
            fputcsv($output, [$row['empresa'], $row['email'], $row['register_form_submit'], $row['created_at']]);
        }

        fclose($output);

        // Enviar la salida del buffer
        ob_end_flush();
        exit;
    }
}

add_action('admin_post_download_empresas_form_csv', 'download_empresas_form_csv');



//Soporte para formularios 
function handle_clientes_submission()
{
    if (!isset($_POST['clientes_form_nonce']) || !wp_verify_nonce($_POST['clientes_form_nonce'], 'clientes_form')) {
        wp_send_json_error('Nonce verification failed.');
        return;
    }

    // Sanitizar campos

    $nombre = sanitize_text_field($_POST['nombre']);
    $apellido = sanitize_text_field($_POST['apellido']);
    $email = sanitize_email($_POST['email']);
    $telefono = sanitize_text_field($_POST['telefono']);
    $objetivo = sanitize_text_field($_POST['objetivo']);
    $comentarios = sanitize_text_field($_POST['comentarios']);
    $register_form_submit = sanitize_text_field($_POST['register_form_submit']);

    // Depurar datos antes de la inserción
    error_log('Datos a insertar: ' . print_r([
        'nombre' => $nombre,
        'apellido' => $apellido,
        'email' => $email,
        'telefono' => $telefono,
        'objetivo' => $objetivo,
        'comentarios' => $comentarios,
        'register_form_submit' => $register_form_submit,
        'created_at' => current_time('mysql')
    ], true));

    // Insertar datos en una tabla personalizada
    global $wpdb;
    $table_name = $wpdb->prefix . 'clientes_entries';
    error_log('Nombre de la tabla: ' . $table_name);  // Añadir un registro para el nombre de la tabla

    $result = $wpdb->insert(
        $table_name,
        [
            'nombre' => $nombre,
            'apellido' => $apellido,
            'email' => $email,
            'telefono' => $telefono,
            'objetivo' => $objetivo,
            'comentarios' => $comentarios,
            'register_form_submit' => $register_form_submit,
            'created_at' => current_time('mysql')
        ]
    );

    // Depurar el resultado de la inserción
    if ($result === false) {
        error_log('Error de inserción: ' . $wpdb->last_error);
        wp_send_json_error('Failed to insert data: ' . $wpdb->last_error);
    } else {
        wp_send_json_success('Form submitted successfully.');
    }
}
add_action('wp_ajax_nopriv_handle_clientes_submission', 'handle_clientes_submission');
add_action('wp_ajax_handle_clientes_submission', 'handle_clientes_submission');

function shortcode_form_clientes_form_shortcode()
{
    ob_start();
?>
    <form id="clientesForm" name="contact-form" class="row mb-0" action="#" method="post">
        <div class="col-md-6 col-sm-12 form-group">
            <input type="text" id="first-name" name="nombre" autocomplete="off" class="form-control" placeholder="Primer nombre">
        </div>
        <div class="col-md-6 col-sm-12  form-group">
            <input type="text" id="last-name" name="apellido" autocomplete="off" class="form-control" placeholder="Apellido">
        </div>
        <div class="col-md-6 col-sm-12 form-group">
            <input type="email" id="email" name="email" autocomplete="off" class="required email form-control" placeholder="Email">
        </div>
        <div class="col-md-6 col-sm-12 form-group">
            <input type="text" id="telefono" name="telefono" autocomplete="off" class="form-control" placeholder="Teléfono">
        </div>
        <div class="col-12 form-group">
            <input type="text" id="subject" name="objetivo" autocomplete="off" class="form-control" placeholder="Objetivo">
        </div>
        <div class="col-12 form-group">
            <textarea id="comments" name="comentarios" rows="4" class="form-control" placeholder="Comentarios"></textarea>
        </div>
        <div class="col-12">
            <!-- <button class="button m-0 w-100" id="register_form_submit" name="register_form_submit" value="register">Enviar</button> -->
            <input type="submit" class="button m-0 w-100" id="register_form_submit" value="Enviar" name="register_form_submit">
        </div>
        <input type="hidden" name="action" value="handle_clientes_submission"><input type="hidden" name="clientes_form_nonce" value='<?php echo wp_create_nonce("clientes_form"); ?>'>
    </form>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <script>
    jQuery(document).ready(function($) {
        $("#clientesForm").submit(function(event) {
            event.preventDefault();

            // Validar campos requeridos antes de enviar
            var isValid = true;
            $(this).find(".required").each(function() {
                if ($.trim($(this).val()) === "") {
                    isValid = false;
                    $(this).addClass("error"); // Agregar una clase de error para indicar el campo vacío
                } else {
                    $(this).removeClass("error");
                }
            });

            // Mostrar mensaje de error si algún campo está vacío
            if (!isValid) {
                showToast('No se puede enviar. Por favor, complete todos los campos requeridos.', 'error');
                return; // Salir de la función si hay campos vacíos
            }

            // Si todos los campos están llenos, continuar con el envío AJAX
            var formData = $(this).serialize(); // Serializar los datos del formulario

            $.ajax({
                url: "<?php echo admin_url("admin-ajax.php"); ?>", // URL del admin-ajax.php para manejar la solicitud
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        // Verificamos si la página de confirmación existe haciendo una solicitud HEAD
                        var thankYouPageUrl = "<?php echo site_url('/confirm'); ?>";

                        $.ajax({
                            url: thankYouPageUrl,
                            type: 'HEAD',
                            success: function() {
                                $("#clientesForm")[0].reset(); // Limpiar los campos del formulario
                                window.location.href = thankYouPageUrl; // Redirigir si la página existe
                            },
                            error: function() {
                                showToast('Datos enviados con éxito.', 'success');
                                $("#clientesForm")[0].reset(); // Limpiar los campos del formulario
                            }
                        });
                    } else {
                        showToast('Error al insertar los datos: ' + response.data, 'error');
                    }
                },
                error: function() {
                    showToast('Hubo un problema al procesar el formulario.', 'error');
                }
            });
        });

        // Función para mostrar el toast nativo de WordPress con estilo mejorado
        function showToast(message, type) {
            var toastClass = (type === 'success') ? 'notice-success' : 'notice-error';
            var toast = `
                 <div class="notice ` + toastClass + ` is-dismissible" style="position: fixed; bottom: 20px; left: 20px; z-index: 9999; max-width: 300px; background: #d1e7dd; border-left: 4px solid #0a3622; border-top: 1px solid #0a3622; border-bottom: 1px solid #0a3622; border-right: 1px solid #0a3622; border-radius: 4px; padding: 15px 10px 5px 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <p style="color: ` + (type === 'success' ? '#0a3622' : '#a32121') + `!important; font-size: 14px; font-weight: 500">` + message + `</p>
            </div>
            `;
            $('body').append(toast);

            // Permitir cerrar el toast manualmente
            $('.notice.is-dismissible').on('click', '.notice-dismiss', function() {
                $(this).parent().remove();
            });

            // Desaparecer automáticamente después de 5 segundos
            setTimeout(function() {
                $('.notice').fadeOut(function() {
                    $(this).remove();
                });
            }, 3000);
        }
    });
    </script>
<?php
    return ob_get_clean();
}
add_shortcode('shortcode_form_clientes', 'shortcode_form_clientes_form_shortcode');

function register_clientes_menu_page()
{
    // Verifica si el usuario tiene los permisos necesarios
        if (!current_user_can('manage_options')) {
            return;
        }
    add_menu_page(
        'Clientes Entries',
        'Entradas form Clientes',
        'manage_options',
        'clientes',
        'clientes_page',
        'dashicons-list-view',
        6
    );
}
add_action('admin_menu', 'register_clientes_menu_page');



function clientes_page()
{
    if (!current_user_can('manage_options')) {
        return; // Restringe el acceso a la página administrativa de clientes
    }
    // // Muestra el contenido de la página
    contact_form_clientes_page();
}

function contact_form_clientes_page()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    global $wpdb;
    $slug = 'clientes';
    $table_name = $wpdb->prefix . $slug . '_entries';

    // Configurar la paginación
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 10; // Número de entradas por página
    $offset = ($paged - 1) * $per_page;

    // Obtener el total de entradas
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");

    // Obtener las entradas con límite y desplazamiento para la paginación
    $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name LIMIT %d OFFSET %d", $per_page, $offset));

    echo '<h1>Entradas de Formulario ' . esc_html('Clientes') . '</h1>';

    // Agregar estilo en línea para los botones
    echo '<style> .form-buttons { display: flex; gap: 10px; margin-bottom: 10px; } </style>';

    // Verificar si hay datos para mostrar
    if ($total > 0) {
        echo '<div class="form-buttons">';

        // Formulario para descargar CSV
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="download_clientes_form_csv">';
        wp_nonce_field('download_csv_nonce', 'download_csv_nonce_field');
        echo '<input type="submit" name="download_csv" value="Download CSV" class="button button-primary">';
        echo '</form>';

        // Formulario para eliminar todas las entradas
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="delete_all_clientes">';
        wp_nonce_field('delete_all_clientes_nonce', 'delete_all_clientes_nonce_field');
        echo '<input type="submit" name="delete_all_clientes" value="Eliminar todo" class="button button-danger" onclick="return confirm(\'¿Deseas eliminar todas las entradas?\');">';
        echo '</form>';

        echo '</div>';
    } else {
        echo '<p>No hay datos para descargar.</p>';
    }

    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr>';
    echo '<th>' . esc_html(ucfirst('nombre')) . '</th>';
    echo '<th>' . esc_html(ucfirst('apellido')) . '</th>';
    echo '<th>' . esc_html(ucfirst('email')) . '</th>';
    echo '<th>' . esc_html(ucfirst('telefono')) . '</th>';
    echo '<th>' . esc_html(ucfirst('objetivo')) . '</th>';
    echo '<th>' . esc_html(ucfirst('comentarios')) . '</th>';
    echo '<th>' . esc_html(ucfirst('register_form_submit')) . '</th>';
    echo '<th>Date</th>'; // Suponiendo que siempre hay una columna de fecha
    echo '</tr></thead>';
    echo '<tbody>';

    // Crear las filas de la tabla dinámicamente
    foreach ($results as $row) {
        echo '<tr>';
        echo '<td>' . esc_html($row->nombre) . '</td>';
        echo '<td>' . esc_html($row->apellido) . '</td>';
        echo '<td>' . esc_html($row->email) . '</td>';
        echo '<td>' . esc_html($row->telefono) . '</td>';
        echo '<td>' . esc_html($row->objetivo) . '</td>';
        echo '<td>' . esc_html($row->comentarios) . '</td>';
        echo '<td>' . esc_html($row->register_form_submit) . '</td>';
        echo '<td>' . esc_html($row->created_at) . '</td>'; // Columna de fecha
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';

    // Paginador
    $page_links = paginate_links([
        'base' => add_query_arg('paged', '%#%'),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($total / $per_page),
        'current' => $paged
    ]);

    if ($page_links) {
        echo '<div style="left: 0; position: absolute;" class="tablenav"><div class="tablenav-pages">' . $page_links . '</div></div>';
    }
}

// Función para manejar la eliminación de todos los datos
function delete_all_clientes()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['delete_all_clientes']) && check_admin_referer('delete_all_clientes_nonce', 'delete_all_clientes_nonce_field')) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'clientes_entries';

        $wpdb->query("DELETE FROM $table_name");

        wp_redirect(admin_url('admin.php?page=clientes'));
        exit;
    }
}
add_action('admin_post_delete_all_clientes', 'delete_all_clientes');


function create_clientes_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'clientes_entries';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        nombre text NOT NULL,
        apellido text NOT NULL,
        email varchar(255) NOT NULL,
        telefono text NOT NULL,
        objetivo text NOT NULL,
        comentarios text NOT NULL,
        register_form_submit text NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    // Verifica si la tabla se ha creado
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        error_log("Error: la tabla $table_name no se creó.");
    }
}
add_action('after_setup_theme', 'create_clientes_table');
function download_clientes_form_csv()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['download_csv']) && check_admin_referer('download_csv_nonce', 'download_csv_nonce_field')) {
        global $wpdb;
        $slug = 'clientes';
        $table_name = $wpdb->prefix . $slug . '_entries';
        $results = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

        if (empty($results)) {
            return;
        }

        $filename = 'clientes_entries_' . date('Y-m-d') . '.csv';

        // Iniciar el buffer de salida
        ob_start();

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename=' . $filename);

        $output = fopen('php://output', 'w');
        fputcsv($output, ['Nombre', 'Apellido', 'Email', 'Telefono', 'Objetivo', 'Comentarios', 'Register_form_submit', 'Date']);
        foreach ($results as $row) {
            fputcsv($output, [$row['nombre'], $row['apellido'], $row['email'], $row['telefono'], $row['objetivo'], $row['comentarios'], $row['register_form_submit'], $row['created_at']]);
        }

        fclose($output);

        // Enviar la salida del buffer
        ob_end_flush();
        exit;
    }
}

add_action('admin_post_download_clientes_form_csv', 'download_clientes_form_csv');




//Soporte para formularios 
function handle_suscripcion_submission()
{
    if (!isset($_POST['suscripcion_form_nonce']) || !wp_verify_nonce($_POST['suscripcion_form_nonce'], 'suscripcion_form')) {
        wp_send_json_error('Nonce verification failed.');
        return;
    }

    // Sanitizar campos

    $email = sanitize_email($_POST['email']);

    // Depurar datos antes de la inserción
    error_log('Datos a insertar: ' . print_r([
        'email' => $email,
        'created_at' => current_time('mysql')
    ], true));

    // Insertar datos en una tabla personalizada
    global $wpdb;
    $table_name = $wpdb->prefix . 'suscripcion_entries';
    error_log('Nombre de la tabla: ' . $table_name);  // Añadir un registro para el nombre de la tabla

    $result = $wpdb->insert(
        $table_name,
        [
            'email' => $email,
            'created_at' => current_time('mysql')
        ]
    );

    // Depurar el resultado de la inserción
    if ($result === false) {
        error_log('Error de inserción: ' . $wpdb->last_error);
        wp_send_json_error('Failed to insert data: ' . $wpdb->last_error);
    } else {
        wp_send_json_success('Form submitted successfully.');
    }
}
add_action('wp_ajax_nopriv_handle_suscripcion_submission', 'handle_suscripcion_submission');
add_action('wp_ajax_handle_suscripcion_submission', 'handle_suscripcion_submission');

function shortcode_form_suscripcion_form_shortcode()
{
    ob_start();
?>
    <form id="suscripcionForm" action="#" method="post" class="mb-0" novalidate="novalidate">
        <div class="input-group input-group-lg">
            <input type="email" id="widget-subscribe-form-email" name="email" class="form-control required email rounded-0" placeholder="Ingresa tu email">
            <input type="submit" style="color: white;" value="Suscríbete" class="btn btn-success rounded-0">
        </div>
        <input type="hidden" name="action" value="handle_suscripcion_submission"><input type="hidden" name="suscripcion_form_nonce" value='<?php echo wp_create_nonce("suscripcion_form"); ?>'>
    </form>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    jQuery(document).ready(function($) {
        $("#suscripcionForm").submit(function(event) {
            event.preventDefault();

            // Validar campos requeridos antes de enviar
            var isValid = true;
            $(this).find(".required").each(function() {
                if ($.trim($(this).val()) === "") {
                    isValid = false;
                    $(this).addClass("error"); // Agregar una clase de error para indicar el campo vacío
                } else {
                    $(this).removeClass("error");
                }
            });

            // Mostrar mensaje de error si algún campo está vacío
            if (!isValid) {
                showToast('No se puede enviar. Por favor, complete todos los campos requeridos.', 'error');
                return; // Salir de la función si hay campos vacíos
            }

            // Si todos los campos están llenos, continuar con el envío AJAX
            var formData = $(this).serialize(); // Serializar los datos del formulario

            $.ajax({
                url: "<?php echo admin_url("admin-ajax.php"); ?>", // URL del admin-ajax.php para manejar la solicitud
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        // Verificamos si la página de confirmación existe haciendo una solicitud HEAD
                        var thankYouPageUrl = "<?php echo site_url('/confirm'); ?>";

                        $.ajax({
                            url: thankYouPageUrl,
                            type: 'HEAD',
                            success: function() {
                                $("#suscripcionForm")[0].reset(); // Limpiar los campos del formulario
                                window.location.href = thankYouPageUrl; // Redirigir si la página existe
                            },
                            error: function() {
                                showToast('Email enviado con éxito.', 'success');
                                $("#suscripcionForm")[0].reset(); // Limpiar los campos del formulario
                            }
                        });
                    } else {
                        showToast('Error al insertar los datos: ' + response.data, 'error');
                    }
                },
                error: function() {
                    showToast('Hubo un problema al procesar el formulario.', 'error');
                }
            });
        });

        // Función para mostrar el toast nativo de WordPress con estilo mejorado
        function showToast(message, type) {
            var toastClass = (type === 'success') ? 'notice-success' : 'notice-error';
            var toast = `
                 <div class="notice ` + toastClass + ` is-dismissible" style="position: fixed; bottom: 20px; left: 20px; z-index: 9999; max-width: 300px; background: #d1e7dd; border-left: 4px solid #0a3622; border-top: 1px solid #0a3622; border-bottom: 1px solid #0a3622; border-right: 1px solid #0a3622; border-radius: 4px; padding: 15px 10px 5px 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <p style="color: ` + (type === 'success' ? '#0a3622' : '#a32121') + `!important; font-size: 14px; font-weight: 500">` + message + `</p>
            </div>
            `;
            $('body').append(toast);

            // Permitir cerrar el toast manualmente
            $('.notice.is-dismissible').on('click', '.notice-dismiss', function() {
                $(this).parent().remove();
            });

            // Desaparecer automáticamente después de 5 segundos
            setTimeout(function() {
                $('.notice').fadeOut(function() {
                    $(this).remove();
                });
            }, 3000);
        }
    });
    </script>
<?php
    return ob_get_clean();
}
add_shortcode('shortcode_form_suscripcion', 'shortcode_form_suscripcion_form_shortcode');

function register_suscripcion_menu_page()
{
    
    // Verifica si el usuario tiene los permisos necesarios
if (!current_user_can('manage_options')) {
    return;
}
    add_menu_page(
        'Suscripcion Entries',
        'Entradas form Suscripcion',
        'manage_options',
        'suscripcion',
        'suscripcion_page',
        'dashicons-list-view',
        6
    );
}
add_action('admin_menu', 'register_suscripcion_menu_page');

 

function suscripcion_page()
{
    if (!current_user_can('manage_options')) {
        return; // Restringe el acceso a la página administrativa de clientes
    }
    // // Muestra el contenido de la página
    contact_form_suscripcion_page();
}

function contact_form_suscripcion_page()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    global $wpdb;
    $slug = 'suscripcion';
    $table_name = $wpdb->prefix . $slug . '_entries';

    // Configurar la paginación
    $paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 10; // Número de entradas por página
    $offset = ($paged - 1) * $per_page;

    // Obtener el total de entradas
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");

    // Obtener las entradas con límite y desplazamiento para la paginación
    $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name LIMIT %d OFFSET %d", $per_page, $offset));

    echo '<h1>Entradas de Formulario ' . esc_html('Suscripcion') . '</h1>';

    // Agregar estilo en línea para los botones
    echo '<style> .form-buttons { display: flex; gap: 10px; margin-bottom: 10px; } </style>';

    // Verificar si hay datos para mostrar
    if ($total > 0) {
        echo '<div class="form-buttons">';

        // Formulario para descargar CSV
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="download_suscripcion_form_csv">';
        wp_nonce_field('download_csv_nonce', 'download_csv_nonce_field');
        echo '<input type="submit" name="download_csv" value="Download CSV" class="button button-primary">';
        echo '</form>';

        // Formulario para eliminar todas las entradas
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="delete_all_suscripcion">';
        wp_nonce_field('delete_all_suscripcion_nonce', 'delete_all_suscripcion_nonce_field');
        echo '<input type="submit" name="delete_all_suscripcion" value="Eliminar todo" class="button button-danger" onclick="return confirm(\'¿Deseas eliminar todas las entradas?\');">';
        echo '</form>';

        echo '</div>';
    } else {
        echo '<p>No hay datos para descargar.</p>';
    }

    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr>';
    echo '<th>' . esc_html(ucfirst('email')) . '</th>';
    echo '<th>Date</th>'; // Suponiendo que siempre hay una columna de fecha
    echo '</tr></thead>';
    echo '<tbody>';

    // Crear las filas de la tabla dinámicamente
    foreach ($results as $row) {
        echo '<tr>';
        echo '<td>' . esc_html($row->email) . '</td>';
        echo '<td>' . esc_html($row->created_at) . '</td>'; // Columna de fecha
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';

    // Paginador
    $page_links = paginate_links([
        'base' => add_query_arg('paged', '%#%'),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($total / $per_page),
        'current' => $paged
    ]);

    if ($page_links) {
        echo '<div style="left: 0; position: absolute;" class="tablenav"><div class="tablenav-pages">' . $page_links . '</div></div>';
    }
}

// Función para manejar la eliminación de todos los datos
function delete_all_suscripcion()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['delete_all_suscripcion']) && check_admin_referer('delete_all_suscripcion_nonce', 'delete_all_suscripcion_nonce_field')) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'suscripcion_entries';

        $wpdb->query("DELETE FROM $table_name");

        wp_redirect(admin_url('admin.php?page=suscripcion'));
        exit;
    }
}
add_action('admin_post_delete_all_suscripcion', 'delete_all_suscripcion');


function create_suscripcion_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'suscripcion_entries';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        email varchar(255) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    // Verifica si la tabla se ha creado
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        error_log("Error: la tabla $table_name no se creó.");
    }
}
add_action('after_setup_theme', 'create_suscripcion_table');
function download_suscripcion_form_csv()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['download_csv']) && check_admin_referer('download_csv_nonce', 'download_csv_nonce_field')) {
        global $wpdb;
        $slug = 'suscripcion';
        $table_name = $wpdb->prefix . $slug . '_entries';
        $results = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

        if (empty($results)) {
            return;
        }

        $filename = 'suscripcion_entries_' . date('Y-m-d') . '.csv';

        // Iniciar el buffer de salida
        ob_start();

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename=' . $filename);

        $output = fopen('php://output', 'w');
        fputcsv($output, ['Email', 'Date']);
        foreach ($results as $row) {
            fputcsv($output, [$row['email'], $row['created_at']]);
        }

        fclose($output);

        // Enviar la salida del buffer
        ob_end_flush();
        exit;
    }
}

add_action('admin_post_download_suscripcion_form_csv', 'download_suscripcion_form_csv');


// Prueba 



<?php
/**
 * Template for Single
 */
get_header();
?>
		<!-- Main content Start -->
        <main id="main"> <div class="page-template-page-sidebar">

                <!--Page Hero-->

                <section class="page-hero" style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/single/header-news.jpg');">
                </section>
                <!--Page Content-->

                <article class="page-content">
                    <div class="flex-container">
                        <div class="left-column">
                            <h1>Menu</h1>
                            <ul>
                            <li><a href="<?php echo site_url('/nuestra-historia'); ?>">Nuestra historia</a></li>
                            <li><a href="<?php echo site_url('/videos'); ?>">Videos</a></li>
                             
                            <li><a href="<?php echo site_url('/mision-vision'); ?>">Vision, mision...</a></li>
                        </ul>
                        </div>

						<?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
<!-- blog --><div class="right-column">
                            <div id="blog-content">
                                <div class="blog-container">
                                    <div class="blog-left" style="flex: 1 1 100%;">
                                        <div class="post">
                                            <h2><?php the_title(); ?></h2>
                                            <span class="date"><?php the_time("F j, Y"); ?></span>
                                            
											 <p><?php the_content(); ?>
<?php if (comments_open() || get_comments_number()) : comments_template(); endif; ?>
</p>
    
                                        <a style="color: green;" href="#">
                                    </a></div>
                                </div>
                            </div>
                        </div>
						<!-- endblog -->
</div>
    <?php endwhile; ?>
<?php else : ?>
    <p style="text-align: center;">No hay publicaciones disponibles.</p>
<?php endif; ?>

                    </div>
                

            </div>

			<div class="section bg-white my-0   py-0">
				<div class="container-fluid py-5 " style="background: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/section-4.jpg') no-repeat 25% 100% / cover; background-attachment: fixed;">
					<div class="row justify-content-end align-items-md-center min-vh-60 mw-md">
						<div class="col-md-7 col-lg-5">
							<p style="font-size: 1.5rem; color: #212529;" class="mb-2  ">Unimos
								productores locales y clientes globales </p>

							<h2 style="font-weight: 900;" class="display-4 text-transform-none ls-0 font-primary color">Únete a
								Nuestra Red Internacional</h2>
							<div class="subscribe-widget" data-loader="button">
								<div class="widget-subscribe-form-result"></div>
								<!--- formempresas --->
								<form id="login-form" name="login-form" class="row mb-0" action="<?php echo home_url('/'); ?>" method="post">
									<div class="col-12 form-group">
										<input type="text" value="<?php echo get_search_query(); ?>" name="s">
									</div>

									<div class="col-12 form-group">
										
									</div>

									<div class="col-12">
										
									 
									</div>
								<button type="submit"><i class="flaticon-search"></i></button></form>
								<!--- endformempresas --->
							</div>
						</div>
					</div>
				</div>
			</div>
		</article>
	</div>
</main>        
			<!-- Main content End -->
<?php
get_footer();


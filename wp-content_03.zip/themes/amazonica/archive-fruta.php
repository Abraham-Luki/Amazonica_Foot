<?php
/*
Template Name: Frutas Archive
Description: Mi Cpt de frutas
*/

get_header();
?>

		<!-- Main content Start -->
		<main id="main">
			 <div class="page-template-page-sidebar">

				<!--Page Hero-->

				<section class="page-hero" style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/header-news.jpg');">
				</section>
				<!--Page Content-->

				<article class="page-content">
					<div class="flex-container">
						<div class="left-column">
							<h1><?php if (is_post_type_archive()) { echo post_type_archive_title('', false); } ?></h1>
							<ul>
								<li><a href="./nuestra-historia.html">Nuestra historia</a></li>
								<li><a href="./videos.html">Videos</a></li>
								<li><a href="./blog.html">Blog</a></li>
								<li><a href="./mision-vision.html">Visón, misión...</a></li>
							</ul>
						</div>

						<div class="right-column">
							<h1><?php if (is_post_type_archive()) { echo post_type_archive_title('', false); } ?></h1>

							<div class="news-container">

								<?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
<!-- blog --><div class="news-item">								 

									<div class="news-content">
										<h2><?php echo get_post_meta(get_the_ID(), 'titulo', true); ?></h2>
										<p><?php echo get_post_meta(get_the_ID(), 'descripcion', true); ?></p>
										
										
										
										
										<p class="source">
											<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
										</p>
									</div>
								</div><!-- endblog -->
    <?php endwhile; ?>
    <div class="ghtml_pagination">
        <?php
            the_posts_pagination(array(
                "mid_size" => 2,
                "prev_text" => __("Anterior"),
                "next_text" => __("Siguiente"),
                "screen_reader_text" => __("Navegación de publicaciones"),
            ));
        ?>
    </div>
<?php else : ?>
    <p style="text-align: center;">No hay publicaciones disponibles.</p>
<?php endif; ?>









								<div class="navigation">
									<span aria-current="page" class="page-numbers current">1</span>
									<a class="page-numbers" href="page/2/index.html">2</a>
									<a class="page-numbers" href="page/3/index.html">3</a>
									<span class="page-numbers dots">…</span>
									<a class="page-numbers" href="page/9/index.html">9</a>
									<a class="next page-numbers" href="page/2/index.html">Next »</a>
								</div>
							</div>
						</div>
					</div>
				</article>

			</div>
		</main>
		<!-- Main content End -->

<?php
get_footer();
?>


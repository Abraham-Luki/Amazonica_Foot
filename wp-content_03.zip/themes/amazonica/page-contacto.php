<?php
/**
 * Template for Contacto
 */
get_header();
?>
	<!-- Main content Start -->
	<main id="main">
	    
	    <style>
	        .widget p {
    line-height: 1.7;
    padding: 0px 13px;
}
	    </style>
	 

		<!--Page Hero-->


		<section class="page-hero" style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/assets/images/contact-us-header.jpg');">
		</section>
		<!--Page Content-->

		<article class="page-content">
			<div class="container">
				<div class="at-above-post-page addthis_tool" data-url="/"></div>
				<div id="pl-146" class="panel-layout">
					<div style="width: 100%;" id="pg-146-0" class="panel-grid panel-has-style">
						<div class="siteorigin-panels-stretch panel-row-style panel-row-style-for-146-0" data-stretch-type="full-stretched-padded">
							<div id="pgc-146-0-0" class="panel-grid-cell">
								<div id="panel-146-0-0-0" class="so-panel widget widget_sow-editor panel-first-child panel-last-child" data-index="0">
									<div class="panel-widget-style panel-widget-style-for-146-0-0-0">
										<div class="so-widget-sow-editor so-widget-sow-editor-base">
										<?php
										$user_selected_number = 4;
										$args = array(
											'post_type' => 'nosotros',
											'posts_per_page' => $user_selected_number,
											'orderby' => 'date',
											'order' => 'ASC',
											'meta_query' => array(
												array(
													'key' => 'is_active',
													'value' => '1',
													'compare' => '='
												)
											)
										);
										$latest_posts = new WP_Query($args);
										$counter = 1;
										if ($latest_posts->have_posts()) :
											while ($latest_posts->have_posts()) : $latest_posts->the_post();
												if ($counter == $user_selected_number) {
										?>
													<!--- nosotros --->
													<div data-cpt-number="4" class="siteorigin-widget-tinymce textwidget">
														<h1 class="page-title">Contáctanos</h1>
														<h2 class="page-title"><?php the_title(); ?></h2>
														<p><?php the_content(); ?></p>
													</div><!--- endnosotros --->
										<?php
												}
												$counter++;
											endwhile;
										endif;
										wp_reset_postdata();
										?>
									</div>
									</div>
								</div>
							</div>
							<div id="pgc-146-0-1" class="panel-grid-cell">
								<div id="panel-146-0-1-0" class="so-panel widget widget_sow-editor panel-first-child panel-last-child" data-index="1">

									<!-- Antes del formulario -->

									<div class="contact-form-widget panel-widget-style panel-widget-style-for-146-0-1-0">

										<div class="so-widget-sow-editor so-widget-sow-editor-base">
											<div class="siteorigin-widget-tinymce textwidget form_contact">
												<h2 style="color: white;">Solicitud de Información para Exportación</h2>
											 
					 
												<div class="subscribe-widget" data-loader="button">
													<div class="widget-subscribe-form-result"></div>
													
													<?php echo do_shortcode('[shortcode_form_clientes]'); ?>
													
												</div>
												
												

											</div>
										</div>
									</div>
									<!-- Fin  del formulario  -->


								</div>
							</div>
						</div>
					</div>
				</div><!-- AddThis Advanced Settings above via filter on the_content --><!-- AddThis Advanced Settings below via filter on the_content --><!-- AddThis Advanced Settings generic via filter on the_content --><!-- AddThis Share Buttons above via filter on the_content --><!-- AddThis Share Buttons below via filter on the_content -->
				<div class="at-below-post-page addthis_tool" data-url="https://www.camposol.com/contact-us/"></div><!-- AddThis Share Buttons generic via filter on the_content -->
			</div>
		</article>


	</main>
	<!-- Main content End -->
<?php
get_footer();


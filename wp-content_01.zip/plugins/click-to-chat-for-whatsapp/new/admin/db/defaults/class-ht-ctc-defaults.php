<?php
/**
 * default values.. 
 * @since 3.9
 * 
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'HT_CTC_Defaults' ) ) :

class HT_CTC_Defaults {

    public $main_options = '';

    public function __construct() {
    }

    


}

new HT_CTC_Defaults();

endif; // END class_exists check
<?php
/**
 * template: add element details and summary - start
 * @since 3.35
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>

</details>